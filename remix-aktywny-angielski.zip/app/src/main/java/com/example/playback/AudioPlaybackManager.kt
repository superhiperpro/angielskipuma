package com.example.playback

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.repository.CourseRepository
import com.example.model.CourseModule
import com.example.model.LessonItem
import com.example.model.PlaybackState
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

object AudioPlaybackManager {

    private const val TAG = "AudioPlaybackManager"

    private var appContext: Context? = null
    private var repository: CourseRepository? = null

    private var mediaPlayer: MediaPlayer? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    var isVocalBoostEnabled: Boolean = true
        private set

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val _sleepTimerState = MutableStateFlow(SleepTimerState())
    val sleepTimerState: StateFlow<SleepTimerState> = _sleepTimerState.asStateFlow()
    private var sleepTimerJob: Job? = null

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var progressTrackerJob: Job? = null

    private var currentSpeed: Float = 1.0f
    var isRunnerModeActive: Boolean = false
    private var resumeOnFocusGain: Boolean = false

    fun setVocalBoost(enabled: Boolean) {
        isVocalBoostEnabled = enabled
        try {
            loudnessEnhancer?.enabled = enabled
            if (enabled) {
                loudnessEnhancer?.setTargetGain(600) // +6 dB vocal boost for speech clarity
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to toggle vocal boost", e)
        }
    }

    private fun applyVocalEnhancer(audioSessionId: Int) {
        try {
            loudnessEnhancer?.release()
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                setTargetGain(600) // +6.00 dB boost for speech clarity
                enabled = isVocalBoostEnabled
            }
        } catch (e: Exception) {
            Log.w(TAG, "LoudnessEnhancer initialization skipped", e)
        }
    }

    fun setSleepTimer(option: SleepTimerOption) {
        sleepTimerJob?.cancel()
        if (option == SleepTimerOption.END_OF_LESSON) {
            val remaining = ((_playbackState.value.totalDurationMs - _playbackState.value.currentPositionMs) / 1000L).coerceAtLeast(0L)
            _sleepTimerState.value = SleepTimerState(
                isActive = true,
                remainingSeconds = remaining,
                option = option
            )
            return
        }

        val totalSeconds = option.minutes * 60L
        _sleepTimerState.value = SleepTimerState(
            isActive = true,
            remainingSeconds = totalSeconds,
            option = option
        )

        sleepTimerJob = scope.launch {
            var timeLeft = totalSeconds
            while (timeLeft > 0 && isActive) {
                delay(1000L)
                timeLeft--
                _sleepTimerState.value = _sleepTimerState.value.copy(remainingSeconds = timeLeft)
            }
            if (isActive) {
                pause()
                _sleepTimerState.value = SleepTimerState(isActive = false, remainingSeconds = 0L, option = null)
            }
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        _sleepTimerState.value = SleepTimerState(isActive = false, remainingSeconds = 0L, option = null)
    }

    fun init(context: Context, repo: CourseRepository) {
        appContext = context.applicationContext
        repository = repo
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // Restore last playback position if available
        scope.launch(Dispatchers.IO) {
            val lastLesson = repo.getLastPlayedLesson()
            if (lastLesson != null) {
                val entity = repo.manifest.modules.flatMap { it.lessons }
                    .find { it.id == lastLesson.id }
                _playbackState.value = _playbackState.value.copy(
                    currentLesson = lastLesson,
                    totalDurationMs = lastLesson.durationSec * 1000L
                )
            }
        }
    }

    fun playLesson(lesson: LessonItem, startPositionMs: Long = 0L) {
        val context = appContext ?: return
        val repo = repository ?: return

        scope.launch {
            try {
                val safeStartPos = startPositionMs.coerceAtLeast(0L)
                val initialDuration = (lesson.durationSec * 1000L).coerceAtLeast(1000L)

                // Immediately reset position and completed flag so UI doesn't show previous lesson's progress
                _playbackState.value = _playbackState.value.copy(
                    currentLesson = lesson,
                    currentPositionMs = safeStartPos,
                    totalDurationMs = initialDuration,
                    isCompleted = false,
                    isPlaying = false,
                    isBuffering = true,
                    errorMessage = null
                )

                releasePlayer()

                mediaPlayer = MediaPlayer().apply {
                    setWakeMode(context.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )

                    val localFile = repo.getLocalAudioFile(lesson.fileName)
                    val expectedMin = (lesson.sizeBytes * 0.70).toLong().coerceAtLeast(3_000_000L)
                    val isGenuine = repo.isGenuineAudioFile(localFile, expectedMin)
                    val testSample = File(File(context.filesDir, "course_test_samples"), "${lesson.id}.sample.wav")

                    val audioPath = when {
                        isGenuine -> localFile.absolutePath
                        testSample.exists() && testSample.length() > 20_000 -> testSample.absolutePath
                        else -> null
                    }

                    if (audioPath == null) {
                        Log.w(TAG, "Audio file not available for lesson ${lesson.title}")
                        _playbackState.value = _playbackState.value.copy(
                            isPlaying = false,
                            isBuffering = false,
                            errorMessage = "Brak pobranego pliku audio dla lekcji \"${lesson.title}\". Pobierz nagrania z Dysku Google lub wskaż folder z plikami."
                        )
                        return@launch
                    }

                    setDataSource(audioPath)

                    setOnPreparedListener { mp ->
                        val actualDuration = mp.duration.toLong()
                        val expectedDuration = (lesson.durationSec * 1000L).coerceAtLeast(1000L)
                        val duration = actualDuration.coerceAtLeast(expectedDuration)

                        if (actualDuration in 1 until (expectedDuration * 0.60).toLong()) {
                            _playbackState.value = _playbackState.value.copy(
                                errorMessage = "Uwaga: Nagranie na telefonie jest ucięte (${actualDuration / 1000}s z ${lesson.durationSec}s). Pobierz je ponownie."
                            )
                        }

                        val finalStartPos = if (safeStartPos in 1 until duration) safeStartPos else 0L
                        _playbackState.value = _playbackState.value.copy(
                            isBuffering = false,
                            totalDurationMs = duration,
                            currentPositionMs = finalStartPos,
                            isCompleted = false
                        )

                        // Always ensure full stereo volume on output (no channel ducking)
                        try {
                            mp.setVolume(1.0f, 1.0f)
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to set player volume", e)
                        }

                        applyVocalEnhancer(mp.audioSessionId)

                        if (finalStartPos > 0) {
                            mp.seekTo(finalStartPos.toInt())
                        }

                        applySpeed(currentSpeed)
                        requestAudioFocusAndStart()
                    }

                    setOnCompletionListener {
                        handlePlaybackCompletion()
                    }

                    setOnErrorListener { _, what, extra ->
                        Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
                        _playbackState.value = _playbackState.value.copy(
                            isPlaying = false,
                            isBuffering = false,
                            errorMessage = "Błąd odtwarzania pliku audio"
                        )
                        true
                    }

                    prepareAsync()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting playback", e)
                _playbackState.value = _playbackState.value.copy(
                    isPlaying = false,
                    isBuffering = false,
                    errorMessage = e.localizedMessage ?: "Nie udało się otworzyć nagrania"
                )
            }
        }
    }

    private fun requestAudioFocusAndStart() {
        val am = audioManager ?: return
        val hasFocus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                .setWillPauseWhenDucked(false)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener { focusChange ->
                    handleAudioFocusChange(focusChange)
                }
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                { focusChange ->
                    handleAudioFocusChange(focusChange)
                },
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }

        if (hasFocus) {
            resumeOnFocusGain = false
            try {
                mediaPlayer?.setVolume(1.0f, 1.0f)
            } catch (e: Exception) {
                // ignore
            }
            mediaPlayer?.start()
            _playbackState.value = _playbackState.value.copy(isPlaying = true)
            startProgressTracker()
            notifyService()
        }
    }

    private fun handleAudioFocusChange(focusChange: Int) {
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                // Permanent loss (e.g. another music app opened)
                resumeOnFocusGain = false
                pause()
                abandonAudioFocus()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                // Transient loss (e.g. phone call or speech prompt)
                if (mediaPlayer?.isPlaying == true) {
                    resumeOnFocusGain = true
                    pauseInternal()
                } else {
                    resumeOnFocusGain = false
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // In speech/audio language courses, NEVER duck volume!
                // Ducking causes words to become silent or inaudible.
                // Keep volume at full 1.0f on both audio channels.
                try {
                    mediaPlayer?.setVolume(1.0f, 1.0f)
                } catch (e: Exception) {
                    // ignore
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                try {
                    mediaPlayer?.setVolume(1.0f, 1.0f)
                } catch (e: Exception) {
                    // ignore
                }
                // STRICT CHECK: ONLY resume if we were playing before transient focus loss!
                if (resumeOnFocusGain) {
                    resumeOnFocusGain = false
                    play()
                }
            }
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to abandon audio focus", e)
        }
    }

    fun play() {
        if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
            resumeOnFocusGain = false
            requestAudioFocusAndStart()
        } else if (mediaPlayer == null && _playbackState.value.currentLesson != null) {
            playLesson(_playbackState.value.currentLesson!!, _playbackState.value.currentPositionMs)
        }
    }

    fun pause() {
        resumeOnFocusGain = false
        abandonAudioFocus()
        pauseInternal()
    }

    private fun pauseInternal() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _playbackState.value = _playbackState.value.copy(isPlaying = false)
                stopProgressTracker()
                notifyService()
                saveCurrentPosition()
            }
        }
    }

    fun togglePlayPause() {
        if (_playbackState.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun stopAndRelease(stopService: Boolean = true, clearLesson: Boolean = false) {
        resumeOnFocusGain = false
        abandonAudioFocus()
        cancelSleepTimer()
        saveCurrentPosition()
        stopProgressTracker()
        releasePlayer()
        _playbackState.value = _playbackState.value.copy(
            currentLesson = if (clearLesson) null else _playbackState.value.currentLesson,
            isPlaying = false,
            isBuffering = false
        )
        if (stopService) {
            val context = appContext ?: return
            try {
                val stopIntent = Intent(context, AudioPlaybackService::class.java).apply {
                    action = AudioPlaybackService.ACTION_STOP
                }
                context.startService(stopIntent)
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping service", e)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        mediaPlayer?.let { mp ->
            val target = positionMs.coerceIn(0L, _playbackState.value.totalDurationMs)
            mp.seekTo(target.toInt())
            _playbackState.value = _playbackState.value.copy(currentPositionMs = target)
            saveCurrentPosition()
        }
    }

    fun seekBy(deltaMs: Long) {
        val current = _playbackState.value.currentPositionMs
        seekTo(current + deltaMs)
    }

    fun setSpeed(speed: Float) {
        currentSpeed = speed
        applySpeed(speed)
        _playbackState.value = _playbackState.value.copy(playbackSpeed = speed)
    }

    private fun applySpeed(speed: Float) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mediaPlayer?.let { mp ->
                    val params = mp.playbackParams ?: PlaybackParams()
                    params.speed = speed
                    mp.playbackParams = params
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set playback speed: $speed", e)
        }
    }

    fun playNext() {
        val current = _playbackState.value.currentLesson ?: return
        val repo = repository ?: return
        val next = repo.getNextLesson(current)
        if (next != null) {
            scope.launch {
                val progress = repo.getLessonProgress(next.id)
                val isDone = progress?.isCompleted == true
                val lastPos = progress?.lastPositionMs ?: 0L
                val startPos = if (isDone || lastPos >= (next.durationSec * 1000L - 3000L)) 0L else lastPos
                playLesson(next, startPos)
            }
        }
    }

    fun playPrevious() {
        val current = _playbackState.value.currentLesson ?: return
        // If current track is playing > 3 seconds, rewind to beginning, else play previous
        if (_playbackState.value.currentPositionMs > 3000L) {
            seekTo(0L)
        } else {
            val repo = repository ?: return
            val prev = repo.getPreviousLesson(current)
            if (prev != null) {
                scope.launch {
                    val progress = repo.getLessonProgress(prev.id)
                    val isDone = progress?.isCompleted == true
                    val lastPos = progress?.lastPositionMs ?: 0L
                    val startPos = if (isDone || lastPos >= (prev.durationSec * 1000L - 3000L)) 0L else lastPos
                    playLesson(prev, startPos)
                }
            } else {
                seekTo(0L)
            }
        }
    }

    private fun handlePlaybackCompletion() {
        val current = _playbackState.value.currentLesson ?: return
        val pos = _playbackState.value.currentPositionMs
        val total = _playbackState.value.totalDurationMs
        val expectedDur = (current.durationSec * 1000L).coerceAtLeast(1000L)

        // Safety verification: If playback completed when only a fraction was played (<60%),
        // the audio file on storage is incomplete or truncated. Do NOT jump to the next lesson!
        if (pos < (expectedDur * 0.60).toLong() && total < (expectedDur * 0.60).toLong()) {
            Log.w(TAG, "Audio ended prematurely: pos=$pos ms, expected=$expectedDur ms. Suppressing auto-advance.")
            pause()
            _playbackState.value = _playbackState.value.copy(
                isPlaying = false,
                errorMessage = "Nagranie lekcji \"${current.title}\" zakończyło się przedwcześnie (${pos / 1000}s z ${current.durationSec}s). Plik audio jest prawdopodobnie niekompletny — pobierz go ponownie."
            )
            stopProgressTracker()
            notifyService()
            return
        }

        scope.launch(Dispatchers.IO) {
            repository?.markLessonCompleted(current.id, true)
            repository?.updatePlaybackPosition(current.id, _playbackState.value.totalDurationMs, _playbackState.value.totalDurationMs)
        }

        // Check if sleep timer is set to END_OF_LESSON
        if (_sleepTimerState.value.option == SleepTimerOption.END_OF_LESSON) {
            cancelSleepTimer()
            pause()
            _playbackState.value = _playbackState.value.copy(
                isPlaying = false,
                isCompleted = true,
                currentPositionMs = _playbackState.value.totalDurationMs
            )
            stopProgressTracker()
            notifyService()
            return
        }

        val next = repository?.getNextLesson(current)
        if (next != null) {
            // Auto advance to next lesson only if audio played completely
            playLesson(next, 0L)
        } else {
            _playbackState.value = _playbackState.value.copy(
                isPlaying = false,
                isCompleted = true,
                currentPositionMs = _playbackState.value.totalDurationMs
            )
            stopProgressTracker()
            notifyService()
        }
    }

    private fun startProgressTracker() {
        stopProgressTracker()
        progressTrackerJob = scope.launch {
            var halfSecondCounter = 0
            while (isActive) {
                mediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        val pos = mp.currentPosition.toLong()
                        val dur = mp.duration.toLong().coerceAtLeast(_playbackState.value.totalDurationMs)
                        _playbackState.value = _playbackState.value.copy(
                            currentPositionMs = pos,
                            totalDurationMs = dur
                        )

                        val lesson = _playbackState.value.currentLesson
                        if (lesson != null && pos % 5000L < 500L) {
                            repository?.updatePlaybackPosition(lesson.id, pos, dur)
                        }

                        if (_sleepTimerState.value.option == SleepTimerOption.END_OF_LESSON) {
                            val rem = ((dur - pos) / 1000L).coerceAtLeast(0L)
                            _sleepTimerState.value = _sleepTimerState.value.copy(remainingSeconds = rem)
                        }
                    }
                }
                delay(500)
                halfSecondCounter++
                if (halfSecondCounter >= 2) {
                    halfSecondCounter = 0
                    if (mediaPlayer?.isPlaying == true) {
                        repository?.recordListeningTime(1L, isRunnerMode = isRunnerModeActive)
                    }
                }
            }
        }
    }

    private fun stopProgressTracker() {
        progressTrackerJob?.cancel()
        progressTrackerJob = null
    }

    private fun saveCurrentPosition() {
        val lesson = _playbackState.value.currentLesson ?: return
        val pos = _playbackState.value.currentPositionMs
        val dur = _playbackState.value.totalDurationMs
        scope.launch(Dispatchers.IO) {
            repository?.updatePlaybackPosition(lesson.id, pos, dur)
        }
    }

    private fun notifyService() {
        val context = appContext ?: return
        val lesson = _playbackState.value.currentLesson ?: return
        val module = repository?.manifest?.modules?.find { it.id == lesson.moduleId }

        val intent = Intent(context, AudioPlaybackService::class.java).apply {
            action = AudioPlaybackService.ACTION_START_FOREGROUND
            putExtra(AudioPlaybackService.EXTRA_LESSON_TITLE, lesson.title)
            putExtra(AudioPlaybackService.EXTRA_MODULE_TITLE, module?.title ?: "Aktywny Angielski")
            putExtra(AudioPlaybackService.EXTRA_IS_PLAYING, _playbackState.value.isPlaying)
        }

        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to start foreground service", e)
        }
    }

    fun clearErrorMessage() {
        _playbackState.value = _playbackState.value.copy(errorMessage = null)
    }

    private fun releasePlayer() {
        stopProgressTracker()
        try {
            loudnessEnhancer?.release()
        } catch (e: Exception) {
            // ignore
        }
        loudnessEnhancer = null
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // ignore
        }
        mediaPlayer = null
    }
}
