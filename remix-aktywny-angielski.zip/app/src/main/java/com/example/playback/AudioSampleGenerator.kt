package com.example.playback

import android.content.Context
import android.util.Log
import com.example.model.LessonItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.sin

/**
 * AudioSampleGenerator:
 * Generuje w pełni poprawne, standardowe pliki audio WAV (PCM 16-bit, 22050 Hz Mono)
 * z przyjemnym, czytelnym sygnałem lektorsko-akustycznym dla lekcji kursu.
 *
 * Umożliwia natychmiastowe przetestowanie odtwarzacza, przewijania (+/-10s),
 * zmiany prędkości (1.25x, 1.5x), timera uśpienia, trybu Runner Mode,
 * paska MiniPlayer, powiadomień w tle oraz statystyk nawyku i osiągnięć
 * bez konieczności pobierania 312 MB z zewnętrznych serwerów.
 */
object AudioSampleGenerator {

    private const val TAG = "AudioSampleGenerator"
    private const val SAMPLE_RATE = 22050
    private const val NUM_CHANNELS = 1
    private const val BITS_PER_SAMPLE = 16

    /**
     * Generuje próbne nagranie audio dla danej lekcji (np. 30-45 sekund przyjemnego tonu lektorskiego)
     */
    suspend fun generateSampleAudio(context: Context, lesson: LessonItem, durationSeconds: Int = 35): File =
        withContext(Dispatchers.IO) {
            val audioDir = File(context.filesDir, "course_test_samples")
            if (!audioDir.exists()) audioDir.mkdirs()

            val targetFile = File(audioDir, "${lesson.id}.sample.wav")
            if (targetFile.exists() && targetFile.length() > 50_000) {
                return@withContext targetFile
            }

            val totalSamples = SAMPLE_RATE * durationSeconds
            val audioDataSize = totalSamples * NUM_CHANNELS * (BITS_PER_SAMPLE / 8)

            val tempFile = File(audioDir, "${lesson.id}.sample.wav.tmp")
            FileOutputStream(tempFile).use { out ->
                // Write 44-byte WAV header placeholder
                writeWavHeader(out, audioDataSize)

                val buffer = ByteArray(2048)
                var bufferIdx = 0

                // Generate pleasant harmonic chord tones with speech cadence pauses
                val baseFreq = 220.0 + (lesson.lessonNumber * 7 % 140) // Unique melodic tone per lesson
                val chordFreq = baseFreq * 1.5 // Perfect fifth harmonic

                for (i in 0 until totalSamples) {
                    val time = i.toDouble() / SAMPLE_RATE
                    val secondInCycle = time % 4.0 // 4-second speech rhythm pattern

                    // Acoustic envelope simulating spoken phrases: 3s sound, 1s pause
                    val envelope = if (secondInCycle < 2.8) {
                        val attack = (secondInCycle / 0.1).coerceIn(0.0, 1.0)
                        val decay = ((2.8 - secondInCycle) / 0.3).coerceIn(0.0, 1.0)
                        attack * decay
                    } else {
                        0.0
                    }

                    // Gentle sine wave with soft vibrato
                    val vibrato = sin(2.0 * Math.PI * 4.5 * time) * 3.0
                    val sampleValue1 = sin(2.0 * Math.PI * (baseFreq + vibrato) * time)
                    val sampleValue2 = sin(2.0 * Math.PI * chordFreq * time) * 0.4
                    val combinedSample = ((sampleValue1 + sampleValue2) * 0.4 * envelope * 32767.0).toInt()
                        .coerceIn(-32768, 32767)

                    // 16-bit Little Endian
                    buffer[bufferIdx++] = (combinedSample and 0xFF).toByte()
                    buffer[bufferIdx++] = ((combinedSample shr 8) and 0xFF).toByte()

                    if (bufferIdx >= buffer.size) {
                        out.write(buffer, 0, bufferIdx)
                        bufferIdx = 0
                    }
                }

                if (bufferIdx > 0) {
                    out.write(buffer, 0, bufferIdx)
                }
                out.flush()
            }

            if (tempFile.length() > 20_000) {
                if (targetFile.exists()) targetFile.delete()
                tempFile.renameTo(targetFile)
                Log.i(TAG, "Generated sample audio for ${lesson.title} (${targetFile.length()} bytes)")
            } else {
                tempFile.delete()
            }

            targetFile
        }

    /**
     * Generuje próbki dla wszystkich brakujących lekcji w kursie
     */
    suspend fun generateAllMissingSamples(
        context: Context,
        lessons: List<LessonItem>,
        onProgress: (Int, Int) -> Unit
    ): Int = withContext(Dispatchers.IO) {
        var generatedCount = 0
        val total = lessons.size
        lessons.forEachIndexed { index, lesson ->
            val audioDir = File(context.filesDir, "course_test_samples")
            val target = File(audioDir, "${lesson.id}.sample.wav")
            if (!target.exists() || target.length() < 20_000) {
                generateSampleAudio(context, lesson, durationSeconds = 30)
                generatedCount++
            }
            onProgress(index + 1, total)
        }
        generatedCount
    }

    private fun writeWavHeader(out: FileOutputStream, audioDataSize: Int) {
        val totalDataLen = audioDataSize + 36
        val byteRate = SAMPLE_RATE * NUM_CHANNELS * BITS_PER_SAMPLE / 8
        val blockAlign = NUM_CHANNELS * BITS_PER_SAMPLE / 8

        val header = ByteArray(44)
        // RIFF
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        // WAVE
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        // fmt 
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16 // Subchunk1Size (16 for PCM)
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // AudioFormat (1 = PCM)
        header[21] = 0
        header[22] = NUM_CHANNELS.toByte()
        header[23] = 0
        header[24] = (SAMPLE_RATE and 0xff).toByte()
        header[25] = ((SAMPLE_RATE shr 8) and 0xff).toByte()
        header[26] = ((SAMPLE_RATE shr 16) and 0xff).toByte()
        header[27] = ((SAMPLE_RATE shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = blockAlign.toByte()
        header[33] = 0
        header[34] = BITS_PER_SAMPLE.toByte()
        header[35] = 0
        // data
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (audioDataSize and 0xff).toByte()
        header[41] = ((audioDataSize shr 8) and 0xff).toByte()
        header[42] = ((audioDataSize shr 16) and 0xff).toByte()
        header[43] = ((audioDataSize shr 24) and 0xff).toByte()

        out.write(header, 0, 44)
    }
}
