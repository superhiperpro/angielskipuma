package com.example.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState as SystemPlaybackState
import android.os.Build
import android.os.IBinder
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.model.LessonItem

class AudioPlaybackService : Service() {

    private var mediaSession: MediaSession? = null

    private val becomingNoisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                AudioPlaybackManager.pause()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        setupMediaSession()
        try {
            ContextCompat.registerReceiver(
                this,
                becomingNoisyReceiver,
                IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun setupMediaSession() {
        mediaSession = MediaSession(this, "ActiveEnglishAudioSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    AudioPlaybackManager.play()
                }

                override fun onPause() {
                    AudioPlaybackManager.pause()
                }

                override fun onSkipToNext() {
                    AudioPlaybackManager.playNext()
                }

                override fun onSkipToPrevious() {
                    AudioPlaybackManager.playPrevious()
                }

                override fun onFastForward() {
                    AudioPlaybackManager.seekBy(10_000L)
                }

                override fun onRewind() {
                    AudioPlaybackManager.seekBy(-10_000L)
                }

                override fun onSeekTo(pos: Long) {
                    AudioPlaybackManager.seekTo(pos)
                }

                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    val keyEvent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                    }
                    if (keyEvent != null && keyEvent.action == KeyEvent.ACTION_DOWN) {
                        when (keyEvent.keyCode) {
                            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                            KeyEvent.KEYCODE_HEADSETHOOK -> {
                                AudioPlaybackManager.togglePlayPause()
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                                AudioPlaybackManager.play()
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                                AudioPlaybackManager.pause()
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_NEXT -> {
                                AudioPlaybackManager.playNext()
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                                AudioPlaybackManager.playPrevious()
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                                AudioPlaybackManager.seekBy(10_000L)
                                return true
                            }
                            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                                AudioPlaybackManager.seekBy(-10_000L)
                                return true
                            }
                        }
                    }
                    return super.onMediaButtonEvent(mediaButtonIntent)
                }
            })
            isActive = true
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(becomingNoisyReceiver)
        } catch (e: Exception) {
            // ignore
        }
        mediaSession?.apply {
            isActive = false
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_FOREGROUND -> {
                val lessonTitle = intent.getStringExtra(EXTRA_LESSON_TITLE) ?: "Lekcja"
                val moduleTitle = intent.getStringExtra(EXTRA_MODULE_TITLE) ?: "Aktywny Angielski"
                val isPlaying = intent.getBooleanExtra(EXTRA_IS_PLAYING, false)
                startForegroundWithNotification(lessonTitle, moduleTitle, isPlaying)
            }
            ACTION_UPDATE_NOTIFICATION -> {
                val lessonTitle = intent.getStringExtra(EXTRA_LESSON_TITLE) ?: "Lekcja"
                val moduleTitle = intent.getStringExtra(EXTRA_MODULE_TITLE) ?: "Aktywny Angielski"
                val isPlaying = intent.getBooleanExtra(EXTRA_IS_PLAYING, false)
                updateNotification(lessonTitle, moduleTitle, isPlaying)
            }
            ACTION_PLAY -> AudioPlaybackManager.play()
            ACTION_PAUSE -> AudioPlaybackManager.pause()
            ACTION_TOGGLE -> AudioPlaybackManager.togglePlayPause()
            ACTION_REWIND_10 -> AudioPlaybackManager.seekBy(-10_000L)
            ACTION_FORWARD_10 -> AudioPlaybackManager.seekBy(10_000L)
            ACTION_NEXT -> AudioPlaybackManager.playNext()
            ACTION_PREVIOUS -> AudioPlaybackManager.playPrevious()
            ACTION_STOP -> {
                AudioPlaybackManager.stopAndRelease(stopService = false, clearLesson = false)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } else {
                    @Suppress("DEPRECATION")
                    stopForeground(true)
                }
                val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(NOTIFICATION_ID)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Odtwarzacz Aktywnego Angielskiego",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Sterowanie odtwarzaczem audio kursu języka angielskiego"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(lessonTitle: String, moduleTitle: String, isPlaying: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevIntent = Intent(this, AudioPlaybackService::class.java).apply { action = ACTION_PREVIOUS }
        val prevPendingIntent = PendingIntent.getService(this, 1, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val rewIntent = Intent(this, AudioPlaybackService::class.java).apply { action = ACTION_REWIND_10 }
        val rewPendingIntent = PendingIntent.getService(this, 2, rewIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(this, AudioPlaybackService::class.java).apply { action = ACTION_TOGGLE }
        val playPausePendingIntent = PendingIntent.getService(this, 3, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val fwdIntent = Intent(this, AudioPlaybackService::class.java).apply { action = ACTION_FORWARD_10 }
        val fwdPendingIntent = PendingIntent.getService(this, 4, fwdIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val nextIntent = Intent(this, AudioPlaybackService::class.java).apply { action = ACTION_NEXT }
        val nextPendingIntent = PendingIntent.getService(this, 5, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, AudioPlaybackService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(this, 6, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseTitle = if (isPlaying) "Pauza" else "Odtwarzaj"

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(lessonTitle)
            .setContentText(moduleTitle)
            .setSubText("Aktywny Angielski")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openAppPendingIntent)
            .setDeleteIntent(stopPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)

        if (isPlaying) {
            builder.addAction(android.R.drawable.ic_media_rew, "-10s", rewPendingIntent)
            builder.addAction(playPauseIcon, playPauseTitle, playPausePendingIntent)
            builder.addAction(android.R.drawable.ic_media_ff, "+10s", fwdPendingIntent)
            builder.addAction(android.R.drawable.ic_media_next, "Następna", nextPendingIntent)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Zamknij", stopPendingIntent)
        } else {
            builder.addAction(android.R.drawable.ic_media_previous, "Poprzednia", prevPendingIntent)
            builder.addAction(playPauseIcon, playPauseTitle, playPausePendingIntent)
            builder.addAction(android.R.drawable.ic_media_next, "Następna", nextPendingIntent)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Zamknij i wyłącz", stopPendingIntent)
        }

        return builder.build()
    }

    private fun startForegroundWithNotification(lessonTitle: String, moduleTitle: String, isPlaying: Boolean) {
        val notification = buildNotification(lessonTitle, moduleTitle, isPlaying)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        updateMediaSessionState(lessonTitle, moduleTitle, isPlaying)
    }

    private fun updateNotification(lessonTitle: String, moduleTitle: String, isPlaying: Boolean) {
        val notification = buildNotification(lessonTitle, moduleTitle, isPlaying)
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
        updateMediaSessionState(lessonTitle, moduleTitle, isPlaying)
    }

    private fun updateMediaSessionState(lessonTitle: String, moduleTitle: String, isPlaying: Boolean) {
        val pos = AudioPlaybackManager.playbackState.value.currentPositionMs
        val dur = AudioPlaybackManager.playbackState.value.totalDurationMs
        val speed = AudioPlaybackManager.playbackState.value.playbackSpeed

        val stateBuilder = SystemPlaybackState.Builder()
            .setActions(
                SystemPlaybackState.ACTION_PLAY or
                SystemPlaybackState.ACTION_PAUSE or
                SystemPlaybackState.ACTION_PLAY_PAUSE or
                SystemPlaybackState.ACTION_SKIP_TO_NEXT or
                SystemPlaybackState.ACTION_SKIP_TO_PREVIOUS or
                SystemPlaybackState.ACTION_FAST_FORWARD or
                SystemPlaybackState.ACTION_REWIND or
                SystemPlaybackState.ACTION_SEEK_TO
            )
            .setState(
                if (isPlaying) SystemPlaybackState.STATE_PLAYING else SystemPlaybackState.STATE_PAUSED,
                pos,
                speed
            )
        mediaSession?.setPlaybackState(stateBuilder.build())

        val metaBuilder = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, lessonTitle)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, moduleTitle)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, "Aktywny Angielski")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
        mediaSession?.setMetadata(metaBuilder.build())
    }

    companion object {
        const val CHANNEL_ID = "active_english_playback_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_FOREGROUND = "com.example.action.START_FOREGROUND"
        const val ACTION_UPDATE_NOTIFICATION = "com.example.action.UPDATE_NOTIFICATION"
        const val ACTION_PLAY = "com.example.action.PLAY"
        const val ACTION_PAUSE = "com.example.action.PAUSE"
        const val ACTION_TOGGLE = "com.example.action.TOGGLE"
        const val ACTION_REWIND_10 = "com.example.action.REWIND_10"
        const val ACTION_FORWARD_10 = "com.example.action.FORWARD_10"
        const val ACTION_NEXT = "com.example.action.NEXT"
        const val ACTION_PREVIOUS = "com.example.action.PREVIOUS"
        const val ACTION_STOP = "com.example.action.STOP"

        const val EXTRA_LESSON_TITLE = "extra_lesson_title"
        const val EXTRA_MODULE_TITLE = "extra_module_title"
        const val EXTRA_IS_PLAYING = "extra_is_playing"
    }
}
