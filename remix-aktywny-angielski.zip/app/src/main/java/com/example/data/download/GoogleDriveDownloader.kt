package com.example.data.download

import android.content.Context
import android.util.Log
import com.example.data.repository.CourseRepository
import com.example.model.DownloadProgressState
import com.example.model.LessonItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class GoogleDriveDownloader(
    private val context: Context,
    private val repository: CourseRepository
) {
    private val _downloadState = MutableStateFlow(DownloadProgressState())
    val downloadState: StateFlow<DownloadProgressState> = _downloadState.asStateFlow()

    private val isCancelled = AtomicBoolean(false)

    // In-memory cookie store so Google Drive download_warning cookies are retained
    private val cookieStore = ConcurrentHashMap<String, List<Cookie>>()

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .cookieJar(object : CookieJar {
                override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
                    cookieStore[url.host] = cookies
                }

                override fun loadForRequest(url: HttpUrl): List<Cookie> {
                    return cookieStore[url.host] ?: emptyList()
                }
            })
            .build()
    }

    fun cancel() {
        isCancelled.set(true)
    }

    /**
     * Pobiera pojedynczą lekcję na żądanie (np. po kliknięciu ikony pobierania w liście lub odtwarzaczu)
     */
    suspend fun downloadSingleLesson(lesson: LessonItem): Boolean = withContext(Dispatchers.IO) {
        val targetFile = repository.getLocalAudioFile(lesson.fileName)
        if (targetFile.exists() && targetFile.length() > 50_000) {
            repository.markLessonDownloaded(lesson.id, targetFile.absolutePath)
            return@withContext true
        }

        _downloadState.value = _downloadState.value.copy(
            isDownloading = true,
            currentFileName = lesson.title,
            currentFileProgress = 0f,
            statusMessage = "Pobieranie lekcji: ${lesson.title}"
        )

        val success = downloadSingleFile(
            lesson = lesson,
            targetFile = targetFile,
            onProgress = { bytesRead, totalBytes, _ ->
                val progress = if (totalBytes > 0) (bytesRead.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0.5f
                _downloadState.value = _downloadState.value.copy(currentFileProgress = progress)
            }
        )

        if (success) {
            repository.markLessonDownloaded(lesson.id, targetFile.absolutePath)
            _downloadState.value = _downloadState.value.copy(
                isDownloading = false,
                currentFileProgress = 1f,
                statusMessage = "Pobrano lekcję: ${lesson.title}"
            )
        } else {
            _downloadState.value = _downloadState.value.copy(
                isDownloading = false,
                statusMessage = "Nie udało się pobrać z Dysku Google."
            )
        }

        success
    }

    suspend fun downloadAllLessons(): Boolean = withContext(Dispatchers.IO) {
        isCancelled.set(false)
        val allLessons = repository.manifest.modules.flatMap { it.lessons }
        val totalCount = allLessons.size

        _downloadState.value = DownloadProgressState(
            isDownloading = true,
            totalFiles = totalCount,
            downloadedFiles = 0,
            statusMessage = "Przygotowywanie pobierania..."
        )

        val destinationDir = repository.audioDirectory
        var successCount = 0
        var totalBytesDownloaded = 0L

        val startTime = System.currentTimeMillis()
        var lastSpeedCalcTime = startTime
        var bytesSinceLastCalc = 0L

        for ((index, lesson) in allLessons.withIndex()) {
            if (isCancelled.get()) {
                _downloadState.value = _downloadState.value.copy(
                    isDownloading = false,
                    statusMessage = "Pobieranie wstrzymane"
                )
                return@withContext false
            }

            val targetFile = File(destinationDir, lesson.fileName)

            // Check if already downloaded and valid
            if (targetFile.exists() && targetFile.length() > 50_000) {
                successCount++
                repository.markLessonDownloaded(lesson.id, targetFile.absolutePath)
                _downloadState.value = _downloadState.value.copy(
                    downloadedFiles = successCount,
                    overallProgress = successCount.toFloat() / totalCount.toFloat(),
                    currentFileName = lesson.title,
                    currentFileProgress = 1f,
                    statusMessage = "Pobrano ${successCount} z $totalCount lekcji"
                )
                continue
            }

            _downloadState.value = _downloadState.value.copy(
                currentFileName = "${lesson.title} (${index + 1}/$totalCount)",
                currentFileProgress = 0f,
                statusMessage = "Pobieranie: ${lesson.title}"
            )

            val downloadSuccess = downloadSingleFile(
                lesson = lesson,
                targetFile = targetFile,
                onProgress = { fileBytesRead, fileTotalBytes, chunkBytes ->
                    bytesSinceLastCalc += chunkBytes
                    totalBytesDownloaded += chunkBytes

                    val now = System.currentTimeMillis()
                    val timeDiff = now - lastSpeedCalcTime
                    val speedText = if (timeDiff >= 1000) {
                        val speedBytesPerSec = (bytesSinceLastCalc * 1000) / timeDiff
                        bytesSinceLastCalc = 0L
                        lastSpeedCalcTime = now
                        formatSpeed(speedBytesPerSec)
                    } else {
                        _downloadState.value.speedText
                    }

                    val fileProgress = if (fileTotalBytes > 0) {
                        (fileBytesRead.toFloat() / fileTotalBytes.toFloat()).coerceIn(0f, 1f)
                    } else 0f

                    val overall = (successCount.toFloat() + fileProgress) / totalCount.toFloat()

                    _downloadState.value = _downloadState.value.copy(
                        currentFileProgress = fileProgress,
                        overallProgress = overall,
                        speedText = speedText
                    )
                }
            )

            if (downloadSuccess) {
                successCount++
                repository.markLessonDownloaded(lesson.id, targetFile.absolutePath)
                _downloadState.value = _downloadState.value.copy(
                    downloadedFiles = successCount,
                    overallProgress = successCount.toFloat() / totalCount.toFloat()
                )
            } else {
                Log.w("DriveDownloader", "Failed to download ${lesson.fileName}")
            }
        }

        val allDone = successCount >= totalCount
        if (allDone) {
            repository.isCourseDownloaded = true
        }

        _downloadState.value = _downloadState.value.copy(
            isDownloading = false,
            downloadedFiles = successCount,
            overallProgress = if (allDone) 1f else (successCount.toFloat() / totalCount.toFloat()),
            isSuccess = allDone,
            statusMessage = if (allDone) "Wszystkie 43 lekcje pobrane! Gotowy do nauki offline."
            else "Pobrano $successCount z $totalCount plików."
        )

        allDone
    }

    private fun downloadSingleFile(
        lesson: LessonItem,
        targetFile: File,
        onProgress: (bytesRead: Long, totalBytes: Long, chunk: Long) -> Unit
    ): Boolean {
        val tempFile = File(targetFile.parentFile, "${targetFile.name}.tmp")
        val candidateUrls = listOf(
            "https://drive.usercontent.google.com/download?id=${lesson.driveFileId}&export=download&confirm=t",
            "https://drive.google.com/uc?export=download&id=${lesson.driveFileId}&confirm=t",
            "https://docs.google.com/uc?export=download&id=${lesson.driveFileId}"
        )

        for (url in candidateUrls) {
            if (isCancelled.get()) return false

            try {
                var currentUrl = url
                var retryWithConfirm: String? = null

                val request = Request.Builder()
                    .url(currentUrl)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
                    .header("Accept", "*/*")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.w("DriveDownloader", "Response code: ${response.code} for $currentUrl")
                        return@use
                    }

                    val contentType = response.header("Content-Type", "") ?: ""
                    val body = response.body ?: return@use

                    // If Google Drive returned an HTML warning/confirmation page:
                    if (contentType.contains("text/html")) {
                        val htmlContent = body.string()
                        // Extract confirm token from Google Drive warning page
                        val confirmRegex = Regex("""confirm=([0-9A-Za-z_]+)""")
                        val uuidRegex = Regex("""uuid=([0-9A-Za-z_-]+)""")
                        val confirmMatch = confirmRegex.find(htmlContent)
                        val uuidMatch = uuidRegex.find(htmlContent)

                        val confirmToken = confirmMatch?.groupValues?.get(1) ?: "t"
                        val uuidToken = uuidMatch?.groupValues?.get(1)

                        val extra = if (uuidToken != null) "&uuid=$uuidToken" else ""
                        retryWithConfirm = "https://drive.usercontent.google.com/download?id=${lesson.driveFileId}&export=download&confirm=$confirmToken$extra"
                    } else {
                        // Binary stream - write to file
                        val contentLength = if (body.contentLength() > 0) body.contentLength() else lesson.sizeBytes
                        val minExpectedBytes = (lesson.sizeBytes * 0.70).toLong().coerceAtLeast(3_000_000L)

                        body.byteStream().use { input ->
                            FileOutputStream(tempFile).use { output ->
                                val buffer = ByteArray(8192)
                                var bytesRead: Int
                                var totalRead = 0L

                                while (input.read(buffer).also { bytesRead = it } != -1) {
                                    if (isCancelled.get()) {
                                        tempFile.delete()
                                        return false
                                    }
                                    output.write(buffer, 0, bytesRead)
                                    totalRead += bytesRead
                                    onProgress(totalRead, contentLength, bytesRead.toLong())
                                }
                                output.flush()
                            }
                        }

                        // Validate downloaded file: Must NOT be an HTML error page and must have sufficient bytes
                        if (tempFile.length() >= minExpectedBytes && isValidAudioFile(tempFile, minExpectedBytes)) {
                            if (targetFile.exists()) targetFile.delete()
                            tempFile.renameTo(targetFile)
                            return true
                        } else {
                            Log.w("DriveDownloader", "Downloaded file truncated (${tempFile.length()} vs expected $minExpectedBytes)")
                            tempFile.delete()
                        }
                    }
                }

                // If Google Drive gave us a confirmation link, follow it:
                if (retryWithConfirm != null) {
                    val retryReq = Request.Builder()
                        .url(retryWithConfirm)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                        .header("Accept", "*/*")
                        .build()

                    client.newCall(retryReq).execute().use { retryResp ->
                        if (retryResp.isSuccessful) {
                            val retryBody = retryResp.body
                            if (retryBody != null) {
                                val cLength = if (retryBody.contentLength() > 0) retryBody.contentLength() else lesson.sizeBytes
                                val minExpectedBytes = (lesson.sizeBytes * 0.70).toLong().coerceAtLeast(3_000_000L)
                                retryBody.byteStream().use { input ->
                                    FileOutputStream(tempFile).use { output ->
                                        val buffer = ByteArray(8192)
                                        var bytesRead: Int
                                        var totalRead = 0L
                                        while (input.read(buffer).also { bytesRead = it } != -1) {
                                            if (isCancelled.get()) {
                                                tempFile.delete()
                                                return false
                                            }
                                            output.write(buffer, 0, bytesRead)
                                            totalRead += bytesRead
                                            onProgress(totalRead, cLength, bytesRead.toLong())
                                        }
                                        output.flush()
                                    }
                                }
                                if (tempFile.length() >= minExpectedBytes && isValidAudioFile(tempFile, minExpectedBytes)) {
                                    if (targetFile.exists()) targetFile.delete()
                                    tempFile.renameTo(targetFile)
                                    return true
                                } else {
                                    Log.w("DriveDownloader", "Downloaded retry file truncated (${tempFile.length()} vs expected $minExpectedBytes)")
                                    tempFile.delete()
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                Log.e("DriveDownloader", "Error downloading ${lesson.fileName}", e)
            }
        }

        return false
    }

    private fun isValidAudioFile(file: File, minBytes: Long = 3_000_000L): Boolean {
        if (!file.exists() || file.length() < minBytes) return false
        return try {
            val bytes = ByteArray(64)
            file.inputStream().use { it.read(bytes) }
            val headerString = String(bytes, Charsets.ISO_8859_1)
            // Reject HTML documents
            if (headerString.contains("<!DOCTYPE", ignoreCase = true) ||
                headerString.contains("<html", ignoreCase = true) ||
                headerString.contains("Google Drive", ignoreCase = true)) {
                return false
            }
            // Reject WAV sample files
            val isRiffWav = bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte()
            if (isRiffWav) return false

            // Accept ID3 (MP3 tag), 0xFF 0xFB/F3/F2 (MPEG sync), ftyp (M4A)
            val isId3 = bytes[0] == 'I'.code.toByte() && bytes[1] == 'D'.code.toByte() && bytes[2] == '3'.code.toByte()
            val isMp3Sync = (bytes[0].toInt() and 0xFF) == 0xFF && ((bytes[1].toInt() and 0xE0) == 0xE0)
            val isM4a = headerString.contains("ftyp")

            isId3 || isMp3Sync || isM4a || file.length() >= 4_000_000L
        } catch (e: Exception) {
            false
        }
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        return when {
            bytesPerSec > 1024 * 1024 -> String.format("%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
            bytesPerSec > 1024 -> String.format("%.0f KB/s", bytesPerSec / 1024.0)
            else -> "$bytesPerSec B/s"
        }
    }
}
