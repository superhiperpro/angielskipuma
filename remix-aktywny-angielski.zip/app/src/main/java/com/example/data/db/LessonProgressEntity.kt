package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val moduleId: Int,
    val lastPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isCompleted: Boolean = false,
    val isDownloaded: Boolean = false,
    val localFilePath: String? = null,
    val lastPlayedTimestamp: Long = 0L
)
