package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.db.AppDatabase
import com.example.data.db.LessonProgressDao
import com.example.data.db.LessonProgressEntity
import com.example.model.CourseManifest
import com.example.model.CourseModule
import com.example.model.LessonItem
import com.example.model.LessonStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.model.Achievement
import com.example.model.AchievementCategory
import com.example.model.AchievementIcon
import com.example.model.DailyReminderConfig
import com.example.model.DayActivity
import com.example.model.HabitStats
import com.example.notifications.DailyReminderManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class CourseRepository(
    private val context: Context,
    private val dao: LessonProgressDao = AppDatabase.getInstance(context).lessonProgressDao()
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("active_listening_prefs", Context.MODE_PRIVATE)

    val manifest: CourseManifest by lazy {
        loadManifestFromAssets()
    }

    val audioDirectory: File by lazy {
        val dir = File(context.filesDir, "course_audio")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        dir
    }

    private val _isCourseDownloadedFlow = MutableStateFlow(prefs.getBoolean(KEY_IS_COURSE_DOWNLOADED, false))
    val isCourseDownloadedFlow: StateFlow<Boolean> = _isCourseDownloadedFlow.asStateFlow()

    private val _habitStatsFlow = MutableStateFlow(loadHabitStats())
    val habitStatsFlow: StateFlow<HabitStats> = _habitStatsFlow.asStateFlow()

    private val _weeklyActivityFlow = MutableStateFlow<List<DayActivity>>(computeWeeklyActivity())
    val weeklyActivityFlow: StateFlow<List<DayActivity>> = _weeklyActivityFlow.asStateFlow()

    private val _dailyReminderConfigFlow = MutableStateFlow(DailyReminderManager.loadConfig(context))
    val dailyReminderConfigFlow: StateFlow<DailyReminderConfig> = _dailyReminderConfigFlow.asStateFlow()

    private val _newAchievementUnlockedFlow = MutableSharedFlow<Achievement>(extraBufferCapacity = 10)
    val newAchievementUnlockedFlow: SharedFlow<Achievement> = _newAchievementUnlockedFlow.asSharedFlow()

    private val _achievementsFlow = MutableStateFlow<List<Achievement>>(buildInitialAchievements())
    val achievementsFlow: StateFlow<List<Achievement>> = _achievementsFlow.asStateFlow()

    var isCourseDownloaded: Boolean
        get() = prefs.getBoolean(KEY_IS_COURSE_DOWNLOADED, false)
        set(value) {
            prefs.edit().putBoolean(KEY_IS_COURSE_DOWNLOADED, value).apply()
            _isCourseDownloadedFlow.value = value
        }

    init {
        // Initialize DB entries in background if needed
        CoroutineScope(Dispatchers.IO).launch {
            initializeDatabaseEntries()
            verifyLocalFiles()
            _weeklyActivityFlow.value = computeWeeklyActivity()
            refreshAchievements()
        }
    }

    private fun loadManifestFromAssets(): CourseManifest {
        return try {
            val jsonString = context.assets.open("course_manifest.json").bufferedReader().use { it.readText() }
            CourseManifest.fromJson(jsonString)
        } catch (e: Exception) {
            e.printStackTrace()
            CourseManifest("aktywny_angielski_1", "Aktywny Angielski", "", "1Qgebh1GPJ_wXFbah5EMjjl9vVKQJsvSV", "", 0, 0L, emptyList())
        }
    }

    private suspend fun initializeDatabaseEntries() = withContext(Dispatchers.IO) {
        val allLessons = manifest.modules.flatMap { it.lessons }
        val existingProgressList = dao.getAllProgressList()
        val existingMap = existingProgressList.associateBy { it.lessonId }
        val backupCompletedSet = prefs.getStringSet(KEY_BACKUP_COMPLETED_SET, emptySet()) ?: emptySet()

        val entitiesToInsert = mutableListOf<LessonProgressEntity>()
        for (lesson in allLessons) {
            val existing = existingMap[lesson.id]
            val localFile = File(audioDirectory, lesson.fileName)
            val exists = localFile.exists() && localFile.length() > 1000
            val isBackupCompleted = backupCompletedSet.contains(lesson.id)

            if (existing == null) {
                // New lesson: insert with backup completed state if available
                entitiesToInsert.add(
                    LessonProgressEntity(
                        lessonId = lesson.id,
                        moduleId = lesson.moduleId,
                        lastPositionMs = 0L,
                        durationMs = lesson.durationSec * 1000L,
                        isCompleted = isBackupCompleted,
                        isDownloaded = exists,
                        localFilePath = if (exists) localFile.absolutePath else null,
                        lastPlayedTimestamp = 0L
                    )
                )
            } else {
                // PRESERVE user progress: lastPositionMs, isCompleted, lastPlayedTimestamp!
                val shouldBeCompleted = existing.isCompleted || isBackupCompleted
                val updated = existing.copy(
                    moduleId = lesson.moduleId,
                    durationMs = if (existing.durationMs > 0) existing.durationMs else lesson.durationSec * 1000L,
                    isCompleted = shouldBeCompleted,
                    isDownloaded = existing.isDownloaded || exists,
                    localFilePath = existing.localFilePath ?: if (exists) localFile.absolutePath else null
                )
                if (updated != existing) {
                    dao.insertOrUpdate(updated)
                }
            }
        }
        if (entitiesToInsert.isNotEmpty()) {
            dao.insertAllIgnore(entitiesToInsert)
        }
    }

    fun isGenuineAudioFile(file: File, expectedMinBytes: Long = 3_000_000L): Boolean {
        if (!file.exists() || file.length() < expectedMinBytes) return false
        return try {
            val bytes = ByteArray(12)
            file.inputStream().use { it.read(bytes) }
            // If file starts with RIFF, it's a WAV test sample, NOT the real course MP3
            val isRiffWav = bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte()
            if (isRiffWav) return false

            val isId3 = bytes[0] == 'I'.code.toByte() && bytes[1] == 'D'.code.toByte() && bytes[2] == '3'.code.toByte()
            val isMpegSync = (bytes[0].toInt() and 0xFF) == 0xFF && ((bytes[1].toInt() and 0xE0) == 0xE0)
            val headerStr = String(bytes, Charsets.ISO_8859_1)
            val isM4a = headerStr.contains("ftyp")

            isId3 || isMpegSync || isM4a || (file.length() >= 4_000_000L)
        } catch (e: Exception) {
            false
        }
    }

    private fun isWavSampleFile(file: File): Boolean {
        if (!file.exists() || file.length() < 12) return false
        return try {
            val bytes = ByteArray(4)
            file.inputStream().use { it.read(bytes) }
            bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte()
        } catch (e: Exception) {
            false
        }
    }

    suspend fun verifyLocalFiles(): Boolean = withContext(Dispatchers.IO) {
        val allLessons = manifest.modules.flatMap { it.lessons }
        var allExist = true
        var downloadedCount = 0

        for (lesson in allLessons) {
            val file = File(audioDirectory, lesson.fileName)
            val expectedMin = (lesson.sizeBytes * 0.70).toLong().coerceAtLeast(3_000_000L)
            val isValid = isGenuineAudioFile(file, expectedMin)
            if (isValid) {
                downloadedCount++
                dao.updateDownloadStatus(lesson.id, true, file.absolutePath)
            } else {
                allExist = false
                dao.updateDownloadStatus(lesson.id, false, null)
                // If the file is a synthetic sample or severely truncated (<1MB), delete it to unblock clean downloads
                if (file.exists() && (isWavSampleFile(file) || file.length() < 1_000_000L)) {
                    try {
                        file.delete()
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            }
        }

        if (downloadedCount >= allLessons.size && allLessons.isNotEmpty()) {
            isCourseDownloaded = true
            allExist = true
        } else {
            isCourseDownloaded = false
        }
        allExist
    }

    fun getLocalAudioFile(fileName: String): File {
        return File(audioDirectory, fileName)
    }

    fun hasLocalAudioFile(fileName: String): Boolean {
        val file = getLocalAudioFile(fileName)
        val lesson = manifest.modules.flatMap { it.lessons }.find { it.fileName == fileName }
        val expectedMin = if (lesson != null) (lesson.sizeBytes * 0.70).toLong().coerceAtLeast(3_000_000L) else 3_000_000L
        return isGenuineAudioFile(file, expectedMin)
    }

    fun areAllLessonsDownloaded(): Boolean {
        if (isCourseDownloaded) return true
        val allLessons = manifest.modules.flatMap { it.lessons }
        if (allLessons.isEmpty()) return false
        val allPresent = allLessons.all { hasLocalAudioFile(it.fileName) }
        if (allPresent) {
            isCourseDownloaded = true
        }
        return allPresent
    }

    fun getAllProgress(): Flow<Map<String, LessonProgressEntity>> {
        return dao.getAllProgress().map { list ->
            list.associateBy { it.lessonId }
        }
    }

    suspend fun getLessonProgress(lessonId: String): LessonProgressEntity? = withContext(Dispatchers.IO) {
        dao.getProgressForLesson(lessonId)
    }

    fun observeCompletedLessonsCount(): Flow<Int> = dao.observeCompletedCount()

    suspend fun getLastPlayedLesson(): LessonItem? = withContext(Dispatchers.IO) {
        val lastEntity = dao.getLastPlayedLesson()
        if (lastEntity != null) {
            findLessonById(lastEntity.lessonId)
        } else {
            manifest.modules.firstOrNull()?.lessons?.firstOrNull()
        }
    }

    suspend fun updatePlaybackPosition(lessonId: String, positionMs: Long, durationMs: Long) {
        withContext(Dispatchers.IO) {
            val isComplete = if (durationMs > 0) (positionMs.toFloat() / durationMs.toFloat()) >= 0.92f else false
            dao.updatePlaybackPosition(lessonId, positionMs, durationMs, System.currentTimeMillis())
            if (isComplete) {
                dao.updateCompletionStatus(lessonId, true)
                updateCompletedLessonsBackup(lessonId, true)
                refreshAchievements()
            }
        }
    }

    suspend fun markLessonCompleted(lessonId: String, completed: Boolean) {
        withContext(Dispatchers.IO) {
            dao.updateCompletionStatus(lessonId, completed)
            updateCompletedLessonsBackup(lessonId, completed)
            refreshAchievements()
        }
    }

    private fun updateCompletedLessonsBackup(lessonId: String, completed: Boolean) {
        val currentSet = prefs.getStringSet(KEY_BACKUP_COMPLETED_SET, emptySet())?.toMutableSet() ?: mutableSetOf()
        if (completed) {
            currentSet.add(lessonId)
        } else {
            currentSet.remove(lessonId)
        }
        prefs.edit().putStringSet(KEY_BACKUP_COMPLETED_SET, currentSet).apply()
    }

    suspend fun markLessonDownloaded(lessonId: String, localPath: String) {
        withContext(Dispatchers.IO) {
            dao.updateDownloadStatus(lessonId, true, localPath)
            val downloaded = dao.getDownloadedCount()
            if (downloaded >= manifest.totalLessons) {
                isCourseDownloaded = true
            }
        }
    }

    fun findLessonById(lessonId: String): LessonItem? {
        return manifest.modules.flatMap { it.lessons }.find { it.id == lessonId }
    }

    fun getNextLesson(current: LessonItem): LessonItem? {
        val all = manifest.modules.flatMap { it.lessons }
        val index = all.indexOfFirst { it.id == current.id }
        return if (index >= 0 && index < all.size - 1) all[index + 1] else null
    }

    fun getPreviousLesson(current: LessonItem): LessonItem? {
        val all = manifest.modules.flatMap { it.lessons }
        val index = all.indexOfFirst { it.id == current.id }
        return if (index > 0) all[index - 1] else null
    }

    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    private fun getYesterdayDateString(): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(cal.time)
    }

    private fun loadHabitStats(): HabitStats {
        val today = getTodayDateString()
        val lastDate = prefs.getString(KEY_LAST_ACTIVE_DATE, "") ?: ""
        val dailyGoal = prefs.getInt(KEY_DAILY_GOAL_MINUTES, 15)
        val totalSecs = prefs.getLong(KEY_TOTAL_LISTENED_SECONDS, 0L)
        var streak = prefs.getInt(KEY_STREAK_DAYS, 1)

        val todaySecs = if (lastDate == today) {
            prefs.getLong(KEY_TODAY_LISTENED_SECONDS, 0L)
        } else {
            // New day: if last active wasn't yesterday, streak resets to 1 (or 0)
            if (lastDate.isNotEmpty() && lastDate != getYesterdayDateString()) {
                streak = 1
                prefs.edit().putInt(KEY_STREAK_DAYS, 1).apply()
            }
            0L
        }

        return HabitStats(
            dailyGoalMinutes = dailyGoal,
            todayListenedSeconds = todaySecs,
            streakDays = streak.coerceAtLeast(1),
            totalListenedSeconds = totalSecs,
            lastActiveDate = lastDate
        )
    }

    fun setDailyGoal(minutes: Int) {
        val clamped = minutes.coerceIn(5, 120)
        prefs.edit().putInt(KEY_DAILY_GOAL_MINUTES, clamped).apply()
        _habitStatsFlow.value = _habitStatsFlow.value.copy(dailyGoalMinutes = clamped)
        _weeklyActivityFlow.value = computeWeeklyActivity()
    }

    @Synchronized
    fun recordListeningTime(seconds: Long, isRunnerMode: Boolean = false) {
        if (seconds <= 0) return
        val today = getTodayDateString()
        val lastDate = prefs.getString(KEY_LAST_ACTIVE_DATE, "") ?: ""
        var currentStreak = prefs.getInt(KEY_STREAK_DAYS, 1)
        var todaySecs = prefs.getLong(KEY_TODAY_LISTENED_SECONDS, 0L)
        val totalSecs = prefs.getLong(KEY_TOTAL_LISTENED_SECONDS, 0L) + seconds
        val goalMins = prefs.getInt(KEY_DAILY_GOAL_MINUTES, 15)

        // Store daily history for streak grid
        val dailySecsKey = KEY_DAILY_SECS_PREFIX + today
        val currentDayHistoricalSecs = prefs.getLong(dailySecsKey, 0L) + seconds

        // Runner mode tracking
        var runnerSecs = prefs.getLong(KEY_RUNNER_SECONDS, 0L)
        if (isRunnerMode) {
            runnerSecs += seconds
        }

        // Time of day tracking
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val isEarly = currentHour < 8
        val isNight = currentHour >= 22

        if (lastDate == today) {
            todaySecs += seconds
        } else {
            if (lastDate == getYesterdayDateString()) {
                currentStreak += 1
            } else if (lastDate.isNotEmpty()) {
                currentStreak = 1
            }
            todaySecs = seconds
        }

        val editor = prefs.edit()
            .putString(KEY_LAST_ACTIVE_DATE, today)
            .putInt(KEY_STREAK_DAYS, currentStreak)
            .putLong(KEY_TODAY_LISTENED_SECONDS, todaySecs)
            .putLong(KEY_TOTAL_LISTENED_SECONDS, totalSecs)
            .putLong(dailySecsKey, currentDayHistoricalSecs)
            .putLong(KEY_RUNNER_SECONDS, runnerSecs)

        if (isEarly) editor.putBoolean(KEY_HAS_EARLY_BIRD, true)
        if (isNight) editor.putBoolean(KEY_HAS_NIGHT_OWL, true)
        editor.apply()

        _habitStatsFlow.value = HabitStats(
            dailyGoalMinutes = goalMins,
            todayListenedSeconds = todaySecs,
            streakDays = currentStreak,
            totalListenedSeconds = totalSecs,
            lastActiveDate = today
        )
        _weeklyActivityFlow.value = computeWeeklyActivity()

        CoroutineScope(Dispatchers.IO).launch {
            refreshAchievements()
        }
    }

    fun computeWeeklyActivity(): List<DayActivity> {
        val result = mutableListOf<DayActivity>()
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        // Move cal to Monday of current week
        val currentDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val daysFromMonday = if (currentDayOfWeek == Calendar.SUNDAY) 6 else currentDayOfWeek - Calendar.MONDAY
        cal.add(Calendar.DAY_OF_MONTH, -daysFromMonday)

        val todayCal = Calendar.getInstance()
        val todayDateStr = getTodayDateString()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val goal = prefs.getInt(KEY_DAILY_GOAL_MINUTES, 15)

        val dayNames = listOf("Pn", "Wt", "Śr", "Czw", "Pt", "So", "Nd")
        for (i in 0 until 7) {
            val dateStr = sdf.format(cal.time)
            val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
            val isToday = (dateStr == todayDateStr)
            val isFuture = cal.get(Calendar.YEAR) > todayCal.get(Calendar.YEAR) ||
                (cal.get(Calendar.YEAR) == todayCal.get(Calendar.YEAR) && cal.get(Calendar.DAY_OF_YEAR) > todayCal.get(Calendar.DAY_OF_YEAR))

            val listenedSecs = if (isToday) {
                prefs.getLong(KEY_TODAY_LISTENED_SECONDS, 0L)
            } else {
                prefs.getLong(KEY_DAILY_SECS_PREFIX + dateStr, 0L)
            }

            result.add(
                DayActivity(
                    dateString = dateStr,
                    dayOfWeekShort = dayNames[i],
                    dayOfMonth = dayOfMonth,
                    listenedSeconds = listenedSecs,
                    goalMinutes = goal,
                    isToday = isToday,
                    isFuture = isFuture
                )
            )
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return result
    }

    private fun buildInitialAchievements(): List<Achievement> {
        return buildAchievementsList(
            completedLessonsCount = 0,
            completedSet = emptySet(),
            notifyNew = false
        )
    }

    suspend fun refreshAchievements() = withContext(Dispatchers.IO) {
        val completedLessonsCount = dao.getCompletedCount()
        val allProgress = dao.getAllProgressList()
        val completedSet = allProgress.filter { it.isCompleted }.map { it.lessonId }.toSet()
        if (completedSet.isNotEmpty()) {
            val backupSet = prefs.getStringSet(KEY_BACKUP_COMPLETED_SET, emptySet())?.toMutableSet() ?: mutableSetOf()
            backupSet.addAll(completedSet)
            prefs.edit().putStringSet(KEY_BACKUP_COMPLETED_SET, backupSet).apply()
        }

        val list = buildAchievementsList(
            completedLessonsCount = completedLessonsCount,
            completedSet = completedSet,
            notifyNew = true
        )
        _achievementsFlow.value = list
    }

    private fun buildAchievementsList(
        completedLessonsCount: Int,
        completedSet: Set<String>,
        notifyNew: Boolean
    ): List<Achievement> {
        val streak = prefs.getInt(KEY_STREAK_DAYS, 1)
        val totalSecs = prefs.getLong(KEY_TOTAL_LISTENED_SECONDS, 0L)
        val runnerSecs = prefs.getLong(KEY_RUNNER_SECONDS, 0L)
        val hasEarlyBird = prefs.getBoolean(KEY_HAS_EARLY_BIRD, false)
        val hasNightOwl = prefs.getBoolean(KEY_HAS_NIGHT_OWL, false)

        val isModuleCompleted = { moduleId: Int ->
            val mod = manifest.modules.find { it.id == moduleId }
            mod != null && mod.lessons.isNotEmpty() && mod.lessons.all { completedSet.contains(it.id) }
        }

        val isAnyModuleCompleted = manifest.modules.any { module ->
            module.lessons.isNotEmpty() && module.lessons.all { completedSet.contains(it.id) }
        }

        val isMod0Done = isModuleCompleted(0)
        val isMod1Done = isModuleCompleted(1)
        val isMod2Done = isModuleCompleted(2)
        val isMod3Done = isModuleCompleted(3)
        val isMod4Done = isModuleCompleted(4)
        val isModAirportDone = isModuleCompleted(5)
        val isPumaMaster = completedLessonsCount >= manifest.totalLessons && manifest.totalLessons > 0

        val unlockedIds = prefs.getStringSet(KEY_UNLOCKED_ACHIEVEMENTS_SET, emptySet())?.toMutableSet() ?: mutableSetOf()
        val sdf = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val todayFormatted = sdf.format(Date())

        val list = listOf(
            createAchievement(
                id = "first_step",
                title = "Pierwszy Krok",
                description = "Ukończ swoją pierwszą pełną lekcję w kursie",
                category = AchievementCategory.COURSE,
                isUnlocked = completedLessonsCount >= 1,
                progress = (completedLessonsCount.toFloat() / 1f).coerceIn(0f, 1f),
                progressText = if (completedLessonsCount >= 1) "Odblokowano!" else "0 / 1 lekcja",
                icon = AchievementIcon.FIRST_LESSON,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "brave_heart",
                title = "Jesteś dzielny!",
                description = "Brawo! Ukończyłeś 5 lekcji – pokonujesz barierę mówienia i idziesz do przodu!",
                category = AchievementCategory.COURSE,
                isUnlocked = completedLessonsCount >= 5,
                progress = (completedLessonsCount.toFloat() / 5f).coerceIn(0f, 1f),
                progressText = if (completedLessonsCount >= 5) "Odblokowano!" else "$completedLessonsCount / 5 lekcji",
                icon = AchievementIcon.BRAVE_HEART,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "mod_0_done",
                title = "Zasady w Małym Palcu",
                description = "Ukończono Wstęp i Instrukcję! Znasz 3 złote zasady aktywnego treningu słuchania.",
                category = AchievementCategory.COURSE,
                isUnlocked = isMod0Done,
                progress = if (isMod0Done) 1f else 0f,
                progressText = if (isMod0Done) "Odblokowano!" else "Ukończ Wstęp",
                icon = AchievementIcon.MODULE_0_DONE,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "mod_1_done",
                title = "Mistrz Modułu 1",
                description = "Ukończono cały Moduł 1 (lekcje 1–12)! Twój aktywny trening mówienia daje świetne efekty.",
                category = AchievementCategory.COURSE,
                isUnlocked = isMod1Done,
                progress = if (isMod1Done) 1f else 0f,
                progressText = if (isMod1Done) "Odblokowano!" else "Ukończ Moduł 1",
                icon = AchievementIcon.MODULE_1_DONE,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "mod_2_done",
                title = "Mistrz Modułu 2",
                description = "Ukończono cały Moduł 2 (lekcje 13–24)! Zakupy, ceny i codzienna komunikacja opanowane.",
                category = AchievementCategory.COURSE,
                isUnlocked = isMod2Done,
                progress = if (isMod2Done) 1f else 0f,
                progressText = if (isMod2Done) "Odblokowano!" else "Ukończ Moduł 2",
                icon = AchievementIcon.MODULE_2_DONE,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "mod_3_done",
                title = "Mistrz Modułu 3",
                description = "Ukończono cały Moduł 3 (lekcje 25–36)! Poruszasz się swobodnie po mieście i używasz zaawansowanych zwrotów.",
                category = AchievementCategory.COURSE,
                isUnlocked = isMod3Done,
                progress = if (isMod3Done) 1f else 0f,
                progressText = if (isMod3Done) "Odblokowano!" else "Ukończ Moduł 3",
                icon = AchievementIcon.MODULE_3_DONE,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "mod_4_done",
                title = "Mistrz Modułu 4",
                description = "Ukończono Moduł 4! Rozumiesz naturalny angielski ze słuchu bez zastanawiania.",
                category = AchievementCategory.COURSE,
                isUnlocked = isMod4Done,
                progress = if (isMod4Done) 1f else 0f,
                progressText = if (isMod4Done) "Odblokowano!" else "Ukończ Moduł 4",
                icon = AchievementIcon.MODULE_4_DONE,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "mod_airport_done",
                title = "Podróżnik Bez Granic",
                description = "Ukończono Dodatek Lotniskowy! Żadna sytuacja na lotnisku i w podróży Cię nie zaskoczy.",
                category = AchievementCategory.COURSE,
                isUnlocked = isModAirportDone,
                progress = if (isModAirportDone) 1f else 0f,
                progressText = if (isModAirportDone) "Odblokowano!" else "Ukończ Dodatek",
                icon = AchievementIcon.MODULE_AIRPORT_DONE,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "streak_3",
                title = "Iskra Regularności",
                description = "Utrzymaj 3 dni aktywnej nauki z rzędu",
                category = AchievementCategory.STREAK,
                isUnlocked = streak >= 3,
                progress = (streak.toFloat() / 3f).coerceIn(0f, 1f),
                progressText = if (streak >= 3) "Odblokowano!" else "$streak / 3 dni",
                icon = AchievementIcon.STREAK_3,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "streak_7",
                title = "Tydzień Ognia",
                description = "Utrzymaj pełny tydzień (7 dni) nauki z rzędu",
                category = AchievementCategory.STREAK,
                isUnlocked = streak >= 7,
                progress = (streak.toFloat() / 7f).coerceIn(0f, 1f),
                progressText = if (streak >= 7) "Odblokowano!" else "$streak / 7 dni",
                icon = AchievementIcon.STREAK_7,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "streak_14",
                title = "Nawyk ze Stali",
                description = "Utrzymaj 14 dni nieprzerwanej nauki",
                category = AchievementCategory.STREAK,
                isUnlocked = streak >= 14,
                progress = (streak.toFloat() / 14f).coerceIn(0f, 1f),
                progressText = if (streak >= 14) "Odblokowano!" else "$streak / 14 dni",
                icon = AchievementIcon.STREAK_14,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "total_1h",
                title = "Pierwsza Godzina",
                description = "Przesłuchaj łącznie 60 minut nagrań kursu",
                category = AchievementCategory.TIME,
                isUnlocked = totalSecs >= 3600L,
                progress = (totalSecs.toFloat() / 3600f).coerceIn(0f, 1f),
                progressText = if (totalSecs >= 3600L) "Odblokowano!" else "${totalSecs / 60} / 60 min",
                icon = AchievementIcon.TOTAL_1H,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "total_5h",
                title = "Zanurzenie w Języku",
                description = "Przesłuchaj łącznie 5 godzin angielskiego",
                category = AchievementCategory.TIME,
                isUnlocked = totalSecs >= 18000L,
                progress = (totalSecs.toFloat() / 18000f).coerceIn(0f, 1f),
                progressText = if (totalSecs >= 18000L) "Odblokowano!" else "${"%.1f".format(totalSecs / 3600f)} / 5h",
                icon = AchievementIcon.TOTAL_5H,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "total_10h",
                title = "Złote Ucho",
                description = "Przesłuchaj łącznie 10 godzin materiałów",
                category = AchievementCategory.TIME,
                isUnlocked = totalSecs >= 36000L,
                progress = (totalSecs.toFloat() / 36000f).coerceIn(0f, 1f),
                progressText = if (totalSecs >= 36000L) "Odblokowano!" else "${"%.1f".format(totalSecs / 3600f)} / 10h",
                icon = AchievementIcon.TOTAL_10H,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "runner_warrior",
                title = "Angielski w Ruchu",
                description = "Ucz się w trybie w ruchu lub na spacerze",
                category = AchievementCategory.CHALLENGE,
                isUnlocked = runnerSecs >= 300L,
                progress = (runnerSecs.toFloat() / 300f).coerceIn(0f, 1f),
                progressText = if (runnerSecs >= 300L) "Odblokowano!" else "${runnerSecs / 60} / 5 min",
                icon = AchievementIcon.RUNNER_WARRIOR,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "early_bird",
                title = "Poranny Ptak",
                description = "Ucz się o poranku (przed godz. 8:00)",
                category = AchievementCategory.CHALLENGE,
                isUnlocked = hasEarlyBird,
                progress = if (hasEarlyBird) 1f else 0f,
                progressText = if (hasEarlyBird) "Odblokowano!" else "Przed 8:00 rano",
                icon = AchievementIcon.EARLY_BIRD,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "night_owl",
                title = "Nocny Marek",
                description = "Ucz się wieczorem lub nocą (po godz. 22:00)",
                category = AchievementCategory.CHALLENGE,
                isUnlocked = hasNightOwl,
                progress = if (hasNightOwl) 1f else 0f,
                progressText = if (hasNightOwl) "Odblokowano!" else "Po 22:00",
                icon = AchievementIcon.NIGHT_OWL,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            createAchievement(
                id = "module_master",
                title = "Mistrz Modułu",
                description = "Ukończ w 100% wszystkie lekcje w dowolnym module",
                category = AchievementCategory.COURSE,
                isUnlocked = isAnyModuleCompleted,
                progress = if (isAnyModuleCompleted) 1f else 0f,
                progressText = if (isAnyModuleCompleted) "Odblokowano!" else "Ukończ 1 moduł",
                icon = AchievementIcon.MODULE_MASTER,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            ),
            // THE ULTIMATE MASTER BADGE: SŁODZIAŚNA PUMA!
            createAchievement(
                id = "puma_master",
                title = "Słodziaśna Puma",
                description = if (isPumaMaster)
                    "Ukończono wszystkie 43 lekcje kursu! Uwolniłeś Pumę – biega szczęśliwa i uśmiechnięta jako Twój wierny towarzysz! 🐾"
                else
                    "Legendarne trofeum kursu! Ukończ wszystkie 43 lekcje, uwolnij Pumę i zobacz jej radosny uśmiech!",
                category = AchievementCategory.COURSE,
                isUnlocked = isPumaMaster,
                progress = (completedLessonsCount.toFloat() / manifest.totalLessons.toFloat().coerceAtLeast(1f)).coerceIn(0f, 1f),
                progressText = if (isPumaMaster) "Uwolniona! 🎉" else "$completedLessonsCount / ${manifest.totalLessons} lekcji",
                icon = AchievementIcon.PUMA_MASTER,
                unlockedIds = unlockedIds,
                todayFormatted = todayFormatted,
                notifyNew = notifyNew
            )
        )

        if (notifyNew) {
            prefs.edit().putStringSet(KEY_UNLOCKED_ACHIEVEMENTS_SET, unlockedIds).apply()
        }
        return list
    }

    private fun createAchievement(
        id: String,
        title: String,
        description: String,
        category: AchievementCategory,
        isUnlocked: Boolean,
        progress: Float,
        progressText: String,
        icon: AchievementIcon,
        unlockedIds: MutableSet<String>,
        todayFormatted: String,
        notifyNew: Boolean = true
    ): Achievement {
        val wasAlreadyUnlocked = unlockedIds.contains(id)
        val dateKey = KEY_UNLOCKED_DATE_PREFIX + id

        val isNowUnlocked = isUnlocked || wasAlreadyUnlocked
        val finalProgress = if (isNowUnlocked) 1f else progress
        val finalProgressText = if (isNowUnlocked) "Odblokowano!" else progressText

        val unlockDate = if (isNowUnlocked) {
            if (!wasAlreadyUnlocked) {
                unlockedIds.add(id)
                if (notifyNew) {
                    prefs.edit().putString(dateKey, todayFormatted).apply()
                }
                todayFormatted
            } else {
                prefs.getString(dateKey, todayFormatted) ?: todayFormatted
            }
        } else null

        val achievement = Achievement(
            id = id,
            title = title,
            description = description,
            category = category,
            isUnlocked = isNowUnlocked,
            progress = finalProgress,
            progressText = finalProgressText,
            unlockedDate = unlockDate,
            iconType = icon
        )

        if (notifyNew && isUnlocked && !wasAlreadyUnlocked) {
            _newAchievementUnlockedFlow.tryEmit(achievement)
        }

        return achievement
    }

    fun updateDailyReminderConfig(config: DailyReminderConfig) {
        DailyReminderManager.saveConfig(context, config)
        _dailyReminderConfigFlow.value = config
    }

    fun sendTestDailyReminder() {
        DailyReminderManager.sendTestNotification(context)
    }

    companion object {
        private const val KEY_IS_COURSE_DOWNLOADED = "is_course_downloaded"
        private const val KEY_DAILY_GOAL_MINUTES = "key_daily_goal_minutes"
        private const val KEY_LAST_ACTIVE_DATE = "key_last_active_date"
        private const val KEY_STREAK_DAYS = "key_streak_days"
        private const val KEY_TODAY_LISTENED_SECONDS = "key_today_listened_seconds"
        private const val KEY_TOTAL_LISTENED_SECONDS = "key_total_listened_seconds"
        private const val KEY_DAILY_SECS_PREFIX = "key_daily_secs_"
        private const val KEY_RUNNER_SECONDS = "key_runner_seconds"
        private const val KEY_HAS_EARLY_BIRD = "key_has_early_bird"
        private const val KEY_HAS_NIGHT_OWL = "key_has_night_owl"
        private const val KEY_UNLOCKED_ACHIEVEMENTS_SET = "key_unlocked_achievements_set"
        private const val KEY_UNLOCKED_DATE_PREFIX = "key_unlocked_date_"
        private const val KEY_BACKUP_COMPLETED_SET = "key_backup_completed_set"
    }
}
