package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Log
import com.example.model.CourseManifest
import com.example.model.LessonItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * LocalAudioImporter:
 * Umożliwia użytkownikowi natychmiastowe wskazanie folderu lub plików z nagraniami kursu
 * zapisanych na telefonie (np. z Pobrane/Downloads, Music, karty SD czy chmury).
 *
 * Dopasowuje pliki do 43 lekcji na podstawie:
 * - Numeru lekcji (np. "1", "01", "Lekcja 1", "Lesson 1", "m1_l1")
 * - Tytułu lekcji (np. "Dojazd na lotnisko")
 * - Dokładnej nazwy pliku MP3
 */
class LocalAudioImporter(
    private val context: Context,
    private val repository: CourseRepository
) {
    private val TAG = "LocalAudioImporter"

    data class ImportResult(
        val totalImported: Int,
        val matchedLessons: List<LessonItem>,
        val failedCount: Int = 0,
        val message: String = ""
    )

    /**
     * Importuje pliki audio ze wskazanego drzewa katalogów (SAF OpenDocumentTree)
     */
    suspend fun importFromTreeUri(treeUri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val allLessons = repository.manifest.modules.flatMap { it.lessons }
        val matched = mutableListOf<LessonItem>()
        var failed = 0

        try {
            val contentResolver = context.contentResolver
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)

            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )

            contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                val idIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)

                while (cursor.moveToNext()) {
                    val fileDocId = cursor.getString(idIdx)
                    val displayName = cursor.getString(nameIdx) ?: ""
                    val mimeType = cursor.getString(mimeIdx) ?: ""

                    // If it's an audio file or .mp3/.wav/.m4a
                    if (isAudioFile(displayName, mimeType)) {
                        val matchingLesson = findMatchingLesson(displayName, allLessons)
                        if (matchingLesson != null) {
                            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, fileDocId)
                            val success = copyDocUriToAppStorage(docUri, matchingLesson.fileName)
                            if (success) {
                                val targetFile = repository.getLocalAudioFile(matchingLesson.fileName)
                                repository.markLessonDownloaded(matchingLesson.id, targetFile.absolutePath)
                                matched.add(matchingLesson)
                            } else {
                                failed++
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error importing from tree uri", e)
            return@withContext ImportResult(
                totalImported = matched.size,
                matchedLessons = matched,
                failedCount = failed,
                message = "Błąd odczytu folderu: ${e.localizedMessage}"
            )
        }

        if (matched.size >= allLessons.size && allLessons.isNotEmpty()) {
            repository.isCourseDownloaded = true
        }

        ImportResult(
            totalImported = matched.size,
            matchedLessons = matched,
            failedCount = failed,
            message = if (matched.isNotEmpty()) {
                "Pomyślnie zaimportowano ${matched.size} z ${allLessons.size} lekcji."
            } else {
                "Nie znaleziono pasujących plików MP3 w wybranym folderze."
            }
        )
    }

    /**
     * Importuje listę wybranych bezpośrednio plików (OpenMultipleDocuments / GetMultipleContents)
     */
    suspend fun importFromUris(uris: List<Uri>): ImportResult = withContext(Dispatchers.IO) {
        val allLessons = repository.manifest.modules.flatMap { it.lessons }
        val matched = mutableListOf<LessonItem>()
        var failed = 0

        uris.forEach { uri ->
            val fileName = getFileNameFromUri(uri) ?: ""
            val matchingLesson = findMatchingLesson(fileName, allLessons)
            if (matchingLesson != null) {
                val success = copyDocUriToAppStorage(uri, matchingLesson.fileName)
                if (success) {
                    val targetFile = repository.getLocalAudioFile(matchingLesson.fileName)
                    repository.markLessonDownloaded(matchingLesson.id, targetFile.absolutePath)
                    matched.add(matchingLesson)
                } else {
                    failed++
                }
            }
        }

        if (matched.size >= allLessons.size && allLessons.isNotEmpty()) {
            repository.isCourseDownloaded = true
        }

        ImportResult(
            totalImported = matched.size,
            matchedLessons = matched,
            failedCount = failed,
            message = if (matched.isNotEmpty()) {
                "Zaimportowano ${matched.size} plików audio."
            } else {
                "Nie dopasowano plików do lekcji kursu."
            }
        )
    }

    private fun isAudioFile(name: String, mime: String): Boolean {
        val lower = name.lowercase()
        return mime.startsWith("audio/") ||
                lower.endsWith(".mp3") ||
                lower.endsWith(".wav") ||
                lower.endsWith(".m4a") ||
                lower.endsWith(".aac")
    }

    private fun findMatchingLesson(fileName: String, lessons: List<LessonItem>): LessonItem? {
        val lower = fileName.lowercase().trim()
        val cleanName = lower.replace("_", " ").replace("-", " ")

        // Check if file belongs to Airport module (Module 5: Dodatek Lotniskowy)
        val isAirportLesson = lower.contains("lotnisk") ||
                lower.contains("airport") ||
                lower.contains("odpraw") ||
                lower.contains("bezpiecz") ||
                lower.contains("pokład") ||
                lower.contains("poklad") ||
                lower.contains("samolot")

        // 1. Exact or direct filename match
        val directMatch = lessons.find { lesson ->
            val cleanLessonFile = lesson.fileName.lowercase().replace("_", " ").replace("-", " ")
            cleanName == cleanLessonFile ||
            cleanName.contains(cleanLessonFile.substringBefore(" moja")) ||
            lower.contains(lesson.fileName.lowercase())
        }
        if (directMatch != null) return directMatch

        // 2. Specific Airport module keywords (Module 5)
        if (isAirportLesson) {
            val airportLessons = lessons.filter { it.moduleId == 5 }
            when {
                lower.contains("dojazd") || lower.contains("lotnisko") -> airportLessons.find { it.lessonNumber == 1 }?.let { return it }
                lower.contains("odprawa") || lower.contains("bagaz") || lower.contains("bagaż") -> airportLessons.find { it.lessonNumber == 2 }?.let { return it }
                lower.contains("bezpieczenstw") || lower.contains("bezpieczeństw") || lower.contains("kontrola") -> airportLessons.find { it.lessonNumber == 3 }?.let { return it }
                lower.contains("przekask") || lower.contains("przekąsk") || lower.contains("pokład") || lower.contains("poklad") -> airportLessons.find { it.lessonNumber == 4 }?.let { return it }
                lower.contains("samolot") -> airportLessons.find { it.lessonNumber == 5 }?.let { return it }
            }
            val numMatch = Regex("""\b([1-5])\b""").find(lower)
            if (numMatch != null) {
                val n = numMatch.groupValues[1].toIntOrNull()
                val match = airportLessons.find { it.lessonNumber == n }
                if (match != null) return match
            }
        }

        // Introduction / Wstęp (Module 0)
        if (lower.contains("praktyk") || lower.contains("wstep") || lower.contains("wstęp") || lower.contains("intro")) {
            lessons.find { it.moduleId == 0 }?.let { return it }
        }

        // Bonus lesson (Module 4, Lesson 37)
        if (lower.contains("tam zjesc") || lower.contains("tam zjeść") || lower.contains("chciałbys") || lower.contains("chcialbys")) {
            lessons.find { it.moduleId == 4 }?.let { return it }
        }

        // 3. Match by unique title phrase for standard lessons (Modules 1-3)
        val nonAirportLessons = lessons.filter { it.moduleId in 1..3 }
        for (lesson in nonAirportLessons) {
            val keyPhrase = when (lesson.lessonNumber) {
                1 -> "fantastic"
                2 -> "coffee"
                3 -> "for me"
                4 -> "supermarket"
                5 -> "adam"
                6 -> "restaurant"
                7 -> "hotel"
                8 -> "faster"
                9 -> "phone"
                10 -> "the best"
                11 -> "bigger"
                12 -> "sugar"
                13 -> "beers"
                14 -> "dollars"
                15 -> "how much"
                16 -> "slower"
                17 -> "wife"
                18 -> "help me"
                19 -> "hungry"
                20 -> "busy"
                21 -> "problem"
                22 -> "tired"
                23 -> "email"
                24 -> "understand"
                25 -> "relax"
                26 -> "drink tea"
                27 -> "where are they"
                28 -> "which one"
                29 -> "evening"
                30 -> "visit you"
                31 -> "leave"
                32 -> "how long"
                33 -> "seems easy"
                34 -> "call me"
                35 -> "enough"
                36 -> "my bag"
                else -> null
            }
            if (keyPhrase != null && lower.contains(keyPhrase)) {
                return lesson
            }
        }

        // 4. Match by explicit leading lesson number (e.g. "01.mp3", "1 - It is...", "Lekcja 14")
        if (!isAirportLesson) {
            val numRegex = Regex("""(?:lekcja|lesson|track|nr|\b|^)(\d{1,2})\b""", RegexOption.IGNORE_CASE)
            val match = numRegex.find(lower)
            if (match != null) {
                val num = match.groupValues[1].toIntOrNull()
                if (num != null && num in 1..36) {
                    val lessonByNum = nonAirportLessons.find { it.lessonNumber == num }
                    if (lessonByNum != null) return lessonByNum
                } else if (num == 0) {
                    return lessons.find { it.moduleId == 0 }
                } else if (num == 37) {
                    return lessons.find { it.moduleId == 4 }
                }
            }
        }

        return null
    }

    private fun copyDocUriToAppStorage(sourceUri: Uri, targetFileName: String): Boolean {
        val targetFile = repository.getLocalAudioFile(targetFileName)
        val tempFile = File(targetFile.parentFile, "$targetFileName.import.tmp")

        return try {
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            if (tempFile.length() > 5000) {
                if (targetFile.exists()) targetFile.delete()
                tempFile.renameTo(targetFile)
                true
            } else {
                tempFile.delete()
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy $sourceUri to $targetFileName", e)
            tempFile.delete()
            false
        }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    name = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                }
            }
        }
        if (name == null) {
            name = uri.path?.substringAfterLast('/')
        }
        return name
    }
}
