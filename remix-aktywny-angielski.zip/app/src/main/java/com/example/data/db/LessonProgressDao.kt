package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonProgressDao {

    @Query("SELECT * FROM lesson_progress")
    fun getAllProgress(): Flow<List<LessonProgressEntity>>

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId LIMIT 1")
    suspend fun getProgressForLesson(lessonId: String): LessonProgressEntity?

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId LIMIT 1")
    fun observeProgressForLesson(lessonId: String): Flow<LessonProgressEntity?>

    @Query("SELECT * FROM lesson_progress ORDER BY lastPlayedTimestamp DESC LIMIT 1")
    suspend fun getLastPlayedLesson(): LessonProgressEntity?

    @Query("SELECT * FROM lesson_progress ORDER BY lastPlayedTimestamp DESC LIMIT 1")
    fun observeLastPlayedLesson(): Flow<LessonProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(entity: LessonProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<LessonProgressEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnore(entities: List<LessonProgressEntity>)

    @Query("UPDATE lesson_progress SET lastPositionMs = :positionMs, durationMs = :durationMs, lastPlayedTimestamp = :timestamp WHERE lessonId = :lessonId")
    suspend fun updatePlaybackPosition(lessonId: String, positionMs: Long, durationMs: Long, timestamp: Long)

    @Query("UPDATE lesson_progress SET isCompleted = :completed WHERE lessonId = :lessonId")
    suspend fun updateCompletionStatus(lessonId: String, completed: Boolean)

    @Query("UPDATE lesson_progress SET isDownloaded = :isDownloaded, localFilePath = :localPath WHERE lessonId = :lessonId")
    suspend fun updateDownloadStatus(lessonId: String, isDownloaded: Boolean, localPath: String?)

    @Query("SELECT COUNT(*) FROM lesson_progress WHERE isDownloaded = 1")
    suspend fun getDownloadedCount(): Int

    @Query("SELECT COUNT(*) FROM lesson_progress WHERE isCompleted = 1")
    fun observeCompletedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM lesson_progress WHERE isCompleted = 1")
    suspend fun getCompletedCount(): Int

    @Query("SELECT * FROM lesson_progress")
    suspend fun getAllProgressList(): List<LessonProgressEntity>
}
