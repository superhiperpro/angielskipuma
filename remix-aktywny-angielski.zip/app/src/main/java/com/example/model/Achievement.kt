package com.example.model

enum class AchievementCategory(val label: String) {
    STREAK("Seria i Nawyki"),
    TIME("Czas Słuchania"),
    CHALLENGE("Wyzwania i Styl"),
    COURSE("Postęp Kursu")
}

data class Achievement(
    val id: String,
    val title: String,
    val description: String,
    val category: AchievementCategory,
    val isUnlocked: Boolean,
    val progress: Float, // 0f .. 1f
    val progressText: String,
    val unlockedDate: String? = null,
    val iconType: AchievementIcon
)

enum class AchievementIcon {
    FIRST_LESSON,
    STREAK_3,
    STREAK_7,
    STREAK_14,
    TOTAL_1H,
    TOTAL_5H,
    TOTAL_10H,
    RUNNER_WARRIOR,
    EARLY_BIRD,
    NIGHT_OWL,
    MODULE_MASTER,
    BRAVE_HEART,
    MODULE_0_DONE,
    MODULE_1_DONE,
    MODULE_2_DONE,
    MODULE_3_DONE,
    MODULE_4_DONE,
    MODULE_AIRPORT_DONE,
    PUMA_MASTER
}

data class DayActivity(
    val dateString: String,      // yyyy-MM-dd
    val dayOfWeekShort: String,  // Pn, Wt, Śr, Czw, Pt, So, Nd
    val dayOfMonth: Int,         // 9, 10, ...
    val listenedSeconds: Long,
    val goalMinutes: Int,
    val isToday: Boolean,
    val isFuture: Boolean
) {
    val listenedMinutes: Int get() = (listenedSeconds / 60).toInt()
    val isGoalReached: Boolean get() = listenedMinutes >= goalMinutes && listenedMinutes > 0
    val hasActivity: Boolean get() = listenedSeconds > 0
}

data class DailyReminderConfig(
    val isEnabled: Boolean = false,
    val hour: Int = 18,
    val minute: Int = 0
) {
    val formattedTime: String
        get() = "%02d:%02d".format(hour, minute)
}
