package com.example.model

enum class LessonStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}

data class PlaybackState(
    val currentLesson: LessonItem? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val isCompleted: Boolean = false,
    val errorMessage: String? = null
) {
    val progressFraction: Float
        get() = if (totalDurationMs > 0) {
            (currentPositionMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

data class DownloadProgressState(
    val isDownloading: Boolean = false,
    val totalFiles: Int = 43,
    val downloadedFiles: Int = 0,
    val currentFileName: String = "",
    val currentFileProgress: Float = 0f,
    val overallProgress: Float = 0f,
    val speedText: String = "",
    val statusMessage: String = "",
    val errorMessage: String? = null,
    val isSuccess: Boolean = false
)

enum class SleepTimerOption(val minutes: Int, val label: String) {
    MIN_15(15, "15 min"),
    MIN_30(30, "30 min"),
    MIN_45(45, "45 min"),
    MIN_60(60, "60 min"),
    END_OF_LESSON(-1, "Do końca lekcji")
}

data class SleepTimerState(
    val isActive: Boolean = false,
    val remainingSeconds: Long = 0L,
    val option: SleepTimerOption? = null
) {
    val formattedRemaining: String
        get() {
            val minutes = remainingSeconds / 60
            val seconds = remainingSeconds % 60
            return "%d:%02d".format(minutes, seconds)
        }
}

data class HabitStats(
    val dailyGoalMinutes: Int = 15,
    val todayListenedSeconds: Long = 0L,
    val streakDays: Int = 1,
    val totalListenedSeconds: Long = 0L,
    val lastActiveDate: String = ""
) {
    val todayMinutes: Int get() = (todayListenedSeconds / 60).toInt()
    val totalHours: Float get() = (totalListenedSeconds / 3600f)
    val goalProgressFraction: Float
        get() = if (dailyGoalMinutes > 0) (todayMinutes.toFloat() / dailyGoalMinutes.toFloat()).coerceIn(0f, 1f) else 0f
    val isGoalReached: Boolean get() = todayMinutes >= dailyGoalMinutes

    val formattedTotalTime: String
        get() {
            val totalMins = (totalListenedSeconds / 60).toInt()
            val hours = totalMins / 60
            val mins = totalMins % 60
            return if (hours > 0) "${hours}h ${mins}m" else "${mins} min"
        }
}

