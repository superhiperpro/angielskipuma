package com.example.model

import org.json.JSONObject

data class LessonItem(
    val id: String,
    val moduleId: Int,
    val lessonNumber: Int,
    val title: String,
    val fileName: String,
    val driveFileId: String,
    val sizeBytes: Long,
    val durationSec: Int,
    val globalIndex: Int = 0
)

data class CourseModule(
    val id: Int,
    val title: String,
    val description: String,
    val lessons: List<LessonItem>
)

data class CourseManifest(
    val courseId: String,
    val title: String,
    val description: String,
    val driveFolderId: String,
    val driveFolderUrl: String,
    val totalLessons: Int,
    val totalSizeBytes: Long,
    val modules: List<CourseModule>
) {
    companion object {
        fun fromJson(jsonStr: String): CourseManifest {
            val root = JSONObject(jsonStr)
            val courseId = root.optString("courseId", "aktywny_angielski_1")
            val title = root.optString("title", "Aktywny Angielski")
            val description = root.optString("description", "")
            val driveFolderId = root.optString("driveFolderId", "1Qgebh1GPJ_wXFbah5EMjjl9vVKQJsvSV")
            val driveFolderUrl = root.optString("driveFolderUrl", "")
            val totalLessons = root.optInt("totalLessons", 43)
            val totalSizeBytes = root.optLong("totalSizeBytes", 0L)

            val modulesJson = root.optJSONArray("modules")
            val modulesList = mutableListOf<CourseModule>()
            var globalCounter = 0

            if (modulesJson != null) {
                for (i in 0 until modulesJson.length()) {
                    val mObj = modulesJson.getJSONObject(i)
                    val mId = mObj.getInt("id")
                    val mTitle = mObj.getString("title")
                    val mDesc = mObj.optString("description", "")

                    val lessonsJson = mObj.optJSONArray("lessons")
                    val lessonsList = mutableListOf<LessonItem>()
                    if (lessonsJson != null) {
                        for (j in 0 until lessonsJson.length()) {
                            val lObj = lessonsJson.getJSONObject(j)
                            val lesson = LessonItem(
                                id = lObj.getString("id"),
                                moduleId = mId,
                                lessonNumber = lObj.getInt("lessonNumber"),
                                title = lObj.getString("title"),
                                fileName = lObj.getString("fileName"),
                                driveFileId = lObj.getString("driveFileId"),
                                sizeBytes = lObj.getLong("sizeBytes"),
                                durationSec = lObj.optInt("durationSec", 0),
                                globalIndex = globalCounter++
                            )
                            lessonsList.add(lesson)
                        }
                    }
                    modulesList.add(CourseModule(mId, mTitle, mDesc, lessonsList))
                }
            }

            return CourseManifest(
                courseId = courseId,
                title = title,
                description = description,
                driveFolderId = driveFolderId,
                driveFolderUrl = driveFolderUrl,
                totalLessons = totalLessons,
                totalSizeBytes = totalSizeBytes,
                modules = modulesList
            )
        }
    }
}
