package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.repository.CourseRepository
import java.util.Random

class DailyReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("active_english_course_prefs", Context.MODE_PRIVATE)

        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val isEnabled = prefs.getBoolean("key_daily_reminder_enabled", false)
            val hour = prefs.getInt("key_daily_reminder_hour", 18)
            val minute = prefs.getInt("key_daily_reminder_minute", 0)
            if (isEnabled) {
                DailyReminderManager.scheduleReminder(context, hour, minute)
            }
            return
        }

        val streak = prefs.getInt("key_streak_days", 1)
        val totalSecs = prefs.getLong("key_total_listened_seconds", 0L)

        val messages = listOf(
            "Twoja seria to już $streak dni 🔥! Nie przerywaj łańcucha – 15 minut wystarczy.",
            "Czas na Twój spacer lub przerwę z angielskim 🎧!",
            "Mały krok każdego dnia daje ogromny efekt. Ruszaj z kolejną lekcją! 🚀",
            "Mózg najszybciej uczy się w ruchu 🏃‍♂️. Posłuchaj lekcji już teraz!",
            "Tylko 1 lekcja dzieli Cię od dzisiejszego celu! Zrób to teraz ⭐"
        )
        val message = messages[Random().nextInt(messages.size)]

        showReminderNotification(context, "🔥 Czas na Aktywny Angielski!", message)

        // Reschedule for next day if enabled
        val isEnabled = prefs.getBoolean("key_daily_reminder_enabled", false)
        val hour = prefs.getInt("key_daily_reminder_hour", 18)
        val minute = prefs.getInt("key_daily_reminder_minute", 0)
        if (isEnabled) {
            DailyReminderManager.scheduleReminder(context, hour, minute)
        }
    }

    companion object {
        const val CHANNEL_ID = "channel_daily_reminders"
        const val NOTIFICATION_ID = 2001

        fun showReminderNotification(context: Context, title: String, content: String) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Codzienne przypomnienia",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Motywacyjne przypomnienia o codziennej nauce angielskiego"
                    enableVibration(true)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(content)
                .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            notificationManager.notify(NOTIFICATION_ID, notification)
        }
    }
}
