package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.model.DailyReminderConfig
import java.util.Calendar

object DailyReminderManager {
    private const val PREFS_NAME = "active_english_course_prefs"
    private const val KEY_ENABLED = "key_daily_reminder_enabled"
    private const val KEY_HOUR = "key_daily_reminder_hour"
    private const val KEY_MINUTE = "key_daily_reminder_minute"
    private const val REQUEST_CODE = 3001

    fun loadConfig(context: Context): DailyReminderConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return DailyReminderConfig(
            isEnabled = prefs.getBoolean(KEY_ENABLED, false),
            hour = prefs.getInt(KEY_HOUR, 18),
            minute = prefs.getInt(KEY_MINUTE, 0)
        )
    }

    fun saveConfig(context: Context, config: DailyReminderConfig) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_ENABLED, config.isEnabled)
            .putInt(KEY_HOUR, config.hour)
            .putInt(KEY_MINUTE, config.minute)
            .apply()

        if (config.isEnabled) {
            scheduleReminder(context, config.hour, config.minute)
        } else {
            cancelReminder(context)
        }
    }

    fun scheduleReminder(context: Context, hour: Int, minute: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, DailyReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                cal.timeInMillis,
                pendingIntent
            )
        } catch (e: Exception) {
            try {
                alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    cal.timeInMillis,
                    pendingIntent
                )
            } catch (_: Exception) {}
        }
    }

    fun cancelReminder(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, DailyReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun sendTestNotification(context: Context) {
        DailyReminderReceiver.showReminderNotification(
            context,
            "🔥 Test przypomnienia: Aktywny Angielski",
            "Świetnie! Powiadomienia motywacyjne działają poprawnie. Czas na codzienną dawkę angielskiego w ruchu!"
        )
    }
}
