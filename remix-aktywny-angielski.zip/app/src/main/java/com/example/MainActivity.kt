package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.model.Achievement
import com.example.model.AchievementIcon
import com.example.ui.components.CelebrationBadgeOverlay
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.PumaRescueDialog
import com.example.ui.screens.AudioPlayerScreen
import com.example.ui.screens.CourseListScreen
import com.example.ui.screens.DownloadScreen
import com.example.ui.screens.RunnerModeScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val downloadState by viewModel.downloadState.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()
    val isCourseDownloaded by viewModel.isCourseDownloaded.collectAsState()
    val allProgress by viewModel.allProgress.collectAsState()
    val expandedModuleIds by viewModel.expandedModuleIds.collectAsState()
    val sleepTimerState by viewModel.sleepTimerState.collectAsState()
    val habitStats by viewModel.habitStats.collectAsState()
    val weeklyActivity by viewModel.weeklyActivity.collectAsState()
    val achievements by viewModel.achievements.collectAsState()
    val dailyReminderConfig by viewModel.dailyReminderConfig.collectAsState()
    val isVocalBoostEnabled by viewModel.isVocalBoostEnabled.collectAsState()
    val importStatusMessage by viewModel.importStatusMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var unlockedDialogAchievement by remember { mutableStateOf<Achievement?>(null) }
    var showStartupPumaMission by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(importStatusMessage) {
        importStatusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearImportStatus()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.newAchievementUnlocked.collect { achievement ->
            unlockedDialogAchievement = achievement
        }
    }

    // Request notification permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Storage pickers for audio files / folders
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            viewModel.importFromFolder(uri)
        }
    }

    val filesPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importFromFiles(uris)
        }
    }

    // Handle back button logically for all screens
    BackHandler(enabled = currentScreen != AppScreen.COURSE_LIST) {
        when (currentScreen) {
            AppScreen.RUNNER_MODE -> viewModel.closeRunnerMode()
            AppScreen.PLAYER -> viewModel.closePlayer()
            AppScreen.DOWNLOAD -> viewModel.navigateTo(AppScreen.COURSE_LIST)
            else -> {}
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    if (targetState == AppScreen.PLAYER) {
                        (slideInVertically { it } + fadeIn()).togetherWith(fadeOut())
                    } else if (initialState == AppScreen.PLAYER) {
                        fadeIn().togetherWith(slideOutVertically { it } + fadeOut())
                    } else {
                        fadeIn().togetherWith(fadeOut())
                    }
                },
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    AppScreen.DOWNLOAD -> {
                        DownloadScreen(
                            downloadState = downloadState,
                            isAlreadyDownloaded = isCourseDownloaded,
                            onStartDownload = { viewModel.startDownload() },
                            onCancelDownload = { viewModel.cancelDownload() },
                            onSkipDownload = { viewModel.skipDownloadForNow() },
                            onPickFolder = { folderPickerLauncher.launch(null) },
                            onPickFiles = { filesPickerLauncher.launch(arrayOf("audio/*")) },
                            onGenerateSamples = { viewModel.generateAllSampleAudios() },
                            onBack = { viewModel.navigateTo(AppScreen.COURSE_LIST) }
                        )
                    }
                    AppScreen.COURSE_LIST -> {
                        Box(modifier = Modifier.fillMaxSize()) {
                            CourseListScreen(
                                manifest = viewModel.manifest,
                                progressMap = allProgress,
                                playbackState = playbackState,
                                expandedModuleIds = expandedModuleIds,
                                isCourseDownloaded = isCourseDownloaded,
                                habitStats = habitStats,
                                weeklyActivity = weeklyActivity,
                                achievements = achievements,
                                dailyReminderConfig = dailyReminderConfig,
                                onToggleModule = { viewModel.toggleModuleExpanded(it) },
                                onLessonSelected = { viewModel.playLesson(it) },
                                onOpenDownloadSync = { viewModel.navigateTo(AppScreen.DOWNLOAD) },
                                onContinueLastPlayed = {
                                    if (playbackState.currentLesson != null) {
                                        if (!playbackState.isPlaying) {
                                            viewModel.togglePlayPause()
                                        }
                                        viewModel.openPlayer()
                                    } else {
                                        val firstLesson = viewModel.manifest.modules.firstOrNull()?.lessons?.firstOrNull()
                                        if (firstLesson != null) viewModel.playLesson(firstLesson)
                                    }
                                },
                                onSetDailyGoal = { viewModel.setDailyGoal(it) },
                                onUpdateDailyReminder = { viewModel.updateDailyReminderConfig(it) },
                                onSendTestReminder = { viewModel.sendTestReminder() },
                                onPickFolder = { folderPickerLauncher.launch(null) },
                                onGenerateSamples = { viewModel.generateAllSampleAudios() },
                                onDownloadLesson = { viewModel.downloadSingleLesson(it) }
                            )

                            // Floating Mini Player Bar at bottom
                            if (playbackState.currentLesson != null) {
                                MiniPlayerBar(
                                    playbackState = playbackState,
                                    onBarClick = { viewModel.openPlayer() },
                                    onTogglePlayPause = { viewModel.togglePlayPause() },
                                    onNext = { viewModel.playNext() },
                                    onClose = { viewModel.stopPlaybackAndDismiss() },
                                    modifier = Modifier.align(Alignment.BottomCenter)
                                )
                            }
                        }
                    }
                    AppScreen.PLAYER -> {
                        val currentLessonId = playbackState.currentLesson?.id
                        val isCompleted = currentLessonId != null && allProgress[currentLessonId]?.isCompleted == true

                        AudioPlayerScreen(
                            manifest = viewModel.manifest,
                            playbackState = playbackState,
                            sleepTimerState = sleepTimerState,
                            isCompleted = isCompleted,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onSeekTo = { viewModel.seekTo(it) },
                            onSeekBy = { viewModel.seekBy(it) },
                            onNext = { viewModel.playNext() },
                            onPrevious = { viewModel.playPrevious() },
                            onSpeedChange = { viewModel.setSpeed(it) },
                            onToggleCompleted = {
                                if (currentLessonId != null) {
                                    viewModel.toggleLessonCompletion(currentLessonId)
                                }
                            },
                            onClosePlayer = { viewModel.closePlayer() },
                            onStopAndClose = {
                                viewModel.stopPlaybackAndDismiss()
                                viewModel.closePlayer()
                            },
                            onSetSleepTimer = { viewModel.setSleepTimer(it) },
                            onCancelSleepTimer = { viewModel.cancelSleepTimer() },
                            onOpenRunnerMode = { viewModel.openRunnerMode() },
                            onDismissError = { viewModel.clearErrorMessage() },
                            isVocalBoostEnabled = isVocalBoostEnabled,
                            onToggleVocalBoost = { viewModel.toggleVocalBoost() }
                        )
                    }
                    AppScreen.RUNNER_MODE -> {
                        RunnerModeScreen(
                            manifest = viewModel.manifest,
                            playbackState = playbackState,
                            sleepTimerState = sleepTimerState,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onSeekTo = { viewModel.seekTo(it) },
                            onSeekBy = { viewModel.seekBy(it) },
                            onNext = { viewModel.playNext() },
                            onPrevious = { viewModel.playPrevious() },
                            onSpeedChange = { viewModel.setSpeed(it) },
                            onCloseRunnerMode = { viewModel.closeRunnerMode() },
                            onOpenSleepTimer = { viewModel.openPlayer() }
                        )
                    }
                }
            }

            // Celebration overlay with confetti when achievement unlocked
            unlockedDialogAchievement?.let { achievement ->
                CelebrationBadgeOverlay(
                    achievement = achievement,
                    onDismiss = { unlockedDialogAchievement = null }
                )
            }

            // Puma Rescue Mission Dialog on App Launch
            if (showStartupPumaMission) {
                val totalLessons = viewModel.manifest.totalLessons.coerceAtLeast(1)
                val completedCount = allProgress.values.count { it.isCompleted }
                val isPumaUnlocked = achievements.any { it.iconType == AchievementIcon.PUMA_MASTER && it.isUnlocked }

                PumaRescueDialog(
                    isUnlocked = isPumaUnlocked,
                    completedCount = completedCount,
                    totalLessons = totalLessons,
                    onDismiss = { showStartupPumaMission = false },
                    onStartLearning = {
                        showStartupPumaMission = false
                        if (playbackState.currentLesson != null) {
                            if (!playbackState.isPlaying) {
                                viewModel.togglePlayPause()
                            }
                            viewModel.openPlayer()
                        } else {
                            val firstLesson = viewModel.manifest.modules.firstOrNull()?.lessons?.firstOrNull()
                            if (firstLesson != null) viewModel.playLesson(firstLesson)
                        }
                    }
                )
            }
        }
    }
}
