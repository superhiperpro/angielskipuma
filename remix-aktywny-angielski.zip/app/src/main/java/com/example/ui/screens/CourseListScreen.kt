package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.db.LessonProgressEntity
import com.example.model.Achievement
import com.example.model.AchievementIcon
import com.example.model.CourseManifest
import com.example.model.CourseModule
import com.example.model.DailyReminderConfig
import com.example.model.DayActivity
import com.example.model.HabitStats
import com.example.model.LessonItem
import com.example.model.PlaybackState
import com.example.ui.components.AchievementsSheet
import com.example.ui.components.AudioWaveformView
import com.example.ui.components.DailyHabitCard
import com.example.ui.components.DailyReminderSheet
import com.example.ui.components.PumaRescueDialog
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentIndigo
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CourseListScreen(
    manifest: CourseManifest,
    progressMap: Map<String, LessonProgressEntity>,
    playbackState: PlaybackState,
    expandedModuleIds: Set<Int>,
    isCourseDownloaded: Boolean = false,
    habitStats: HabitStats = HabitStats(),
    weeklyActivity: List<DayActivity> = emptyList(),
    achievements: List<Achievement> = emptyList(),
    dailyReminderConfig: DailyReminderConfig = DailyReminderConfig(),
    onToggleModule: (Int) -> Unit,
    onLessonSelected: (LessonItem) -> Unit,
    onOpenDownloadSync: () -> Unit,
    onContinueLastPlayed: () -> Unit,
    onSetDailyGoal: (Int) -> Unit = {},
    onUpdateDailyReminder: (DailyReminderConfig) -> Unit = {},
    onSendTestReminder: () -> Unit = {},
    onPickFolder: () -> Unit = {},
    onGenerateSamples: () -> Unit = {},
    onDownloadLesson: (LessonItem) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val totalLessons = manifest.totalLessons.coerceAtLeast(1)
    val completedCount = progressMap.values.count { it.isCompleted }
    val courseProgressFraction = (completedCount.toFloat() / totalLessons.toFloat()).coerceIn(0f, 1f)

    var showAchievementsSheet by remember { mutableStateOf(false) }
    var showReminderSheet by remember { mutableStateOf(false) }
    var showPumaRescueDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    // Identify last played lesson or default to first lesson
    val lastPlayedId = progressMap.values.maxByOrNull { it.lastPlayedTimestamp }?.lessonId
    val lastPlayedLesson = manifest.modules.flatMap { it.lessons }.find { it.id == lastPlayedId }
        ?: manifest.modules.firstOrNull()?.lessons?.firstOrNull()

    val filteredLessons = remember(searchQuery, manifest) {
        if (searchQuery.isBlank()) emptyList()
        else {
            val q = searchQuery.trim().lowercase()
            manifest.modules.flatMap { it.lessons }.filter {
                it.title.lowercase().contains(q) ||
                it.lessonNumber.toString() == q ||
                "lekcja ${it.lessonNumber}".contains(q)
            }
        }
    }

    val isPumaUnlocked = remember(achievements) {
        achievements.any { it.iconType == AchievementIcon.PUMA_MASTER && it.isUnlocked }
    }
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Top App Bar & Course Banner
        item {
            CourseHeroHeader(
                manifest = manifest,
                completedCount = completedCount,
                totalLessons = totalLessons,
                progressFraction = courseProgressFraction,
                isCourseDownloaded = isCourseDownloaded,
                isPumaUnlocked = isPumaUnlocked,
                unlockedAchievementsCount = achievements.count { it.isUnlocked },
                totalAchievementsCount = achievements.size,
                onOpenDownloadSync = onOpenDownloadSync,
                onOpenAchievements = { showAchievementsSheet = true },
                onOpenPumaMission = { showPumaRescueDialog = true }
            )
        }

        // Quick Audio Setup Banner (if not all files on disk)
        if (!isCourseDownloaded) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceHighlight),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = AccentCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Nagrania audio kursu",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Pobierz nagrania z Dysku Google lub wskaż pobrany wcześniej folder na telefonie.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onOpenDownloadSync,
                                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudDownload,
                                    contentDescription = null,
                                    tint = DarkSurface,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Pobierz z Dysku",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkSurface
                                )
                            }

                            OutlinedButton(
                                onClick = onPickFolder,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = null,
                                    tint = AccentCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Wskaż folder",
                                    fontSize = 12.sp,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Daily Habit & Streak Card with Weekly Calendar
        item {
            DailyHabitCard(
                habitStats = habitStats,
                weeklyActivity = weeklyActivity,
                unlockedAchievementsCount = achievements.count { it.isUnlocked },
                totalAchievementsCount = achievements.size.coerceAtLeast(11),
                reminderTimeText = if (dailyReminderConfig.isEnabled) dailyReminderConfig.formattedTime else null,
                onSetDailyGoal = onSetDailyGoal,
                onOpenAchievements = { showAchievementsSheet = true },
                onOpenReminder = { showReminderSheet = true }
            )
        }

        // Quick Continue / Resume Card
        if (lastPlayedLesson != null && searchQuery.isBlank()) {
            item {
                ResumeLessonCard(
                    lesson = lastPlayedLesson,
                    progress = progressMap[lastPlayedLesson.id],
                    isCurrentPlaying = playbackState.currentLesson?.id == lastPlayedLesson.id && playbackState.isPlaying,
                    onClick = onContinueLastPlayed
                )
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        text = "Szukaj lekcji (np. lotnisko, hotel, restauracja)...",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Szukaj",
                        tint = AccentCyan,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Wyczyść wyszukiwanie",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = AccentCyan,
                    unfocusedBorderColor = DarkSurfaceHighlight,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp)
                    .testTag("course_search_input")
            )
        }

        if (searchQuery.isNotBlank()) {
            item {
                Text(
                    text = "Wyniki wyszukiwania (${filteredLessons.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 8.dp)
                )
            }

            if (filteredLessons.isEmpty()) {
                item {
                    Text(
                        text = "Brak lekcji odpowiadających '$searchQuery'. Spróbuj wpisać inny zwrot lub numer lekcji.",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
                    )
                }
            } else {
                items(filteredLessons, key = { it.id }) { lesson ->
                    val progress = progressMap[lesson.id]
                    val isCurrent = lesson.id == playbackState.currentLesson?.id
                    LessonItemRow(
                        lesson = lesson,
                        progress = progress,
                        isCurrent = isCurrent,
                        isPlaying = isCurrent && playbackState.isPlaying,
                        onClick = { onLessonSelected(lesson) },
                        onDownloadClick = { onDownloadLesson(lesson) }
                    )
                }
            }
        } else {
            item {
                Text(
                    text = "Moduły kursu",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 12.dp)
                )
            }

            // Modules list
            items(manifest.modules, key = { it.id }) { module ->
                val isExpanded = expandedModuleIds.contains(module.id)
                val moduleProgressList = module.lessons.mapNotNull { progressMap[it.id] }
                val moduleCompletedCount = moduleProgressList.count { it.isCompleted }

                ModuleAccordionCard(
                    module = module,
                    isExpanded = isExpanded,
                    completedCount = moduleCompletedCount,
                    progressMap = progressMap,
                    currentPlayingLessonId = playbackState.currentLesson?.id,
                    isPlaying = playbackState.isPlaying,
                    onToggleExpand = { onToggleModule(module.id) },
                    onLessonClick = onLessonSelected,
                    onDownloadLesson = onDownloadLesson
                )
            }
        }
    }

    if (showAchievementsSheet) {
        AchievementsSheet(
            achievements = achievements,
            onDismiss = { showAchievementsSheet = false }
        )
    }

    if (showReminderSheet) {
        DailyReminderSheet(
            initialConfig = dailyReminderConfig,
            onSaveConfig = { config ->
                onUpdateDailyReminder(config)
                showReminderSheet = false
            },
            onSendTestReminder = onSendTestReminder,
            onDismiss = { showReminderSheet = false }
        )
    }

    if (showPumaRescueDialog) {
        PumaRescueDialog(
            isUnlocked = isPumaUnlocked,
            completedCount = completedCount,
            totalLessons = totalLessons,
            onDismiss = { showPumaRescueDialog = false },
            onStartLearning = {
                showPumaRescueDialog = false
                onContinueLastPlayed()
            }
        )
    }
}

@Composable
private fun CourseHeroHeader(
    manifest: CourseManifest,
    completedCount: Int,
    totalLessons: Int,
    progressFraction: Float,
    isCourseDownloaded: Boolean,
    isPumaUnlocked: Boolean = false,
    unlockedAchievementsCount: Int = 0,
    totalAchievementsCount: Int = 0,
    onOpenDownloadSync: () -> Unit,
    onOpenAchievements: () -> Unit = {},
    onOpenPumaMission: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DarkSurfaceVariant, DarkBackground)
                )
            )
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(listOf(AccentIndigo, AccentCyan))
                        )
                        .padding(2.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.course_cover_art),
                        contentDescription = "Okładka kursu",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "Aktywny Angielski",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Praktyk 2.0 • 43 nagrania audio",
                        fontSize = 13.sp,
                        color = AccentCyan
                    )
                }
            }

            if (!isCourseDownloaded) {
                // Sync / Download settings button - shown only before download is complete
                IconButton(
                    onClick = onOpenDownloadSync,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceHighlight)
                        .testTag("download_sync_icon")
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudDownload,
                        contentDescription = "Pobieranie offline",
                        tint = AccentCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }
            } else {
                // Cloud icon REMOVED! Replaced by an elegant offline status chip
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = AccentEmerald.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, AccentEmerald.copy(alpha = 0.4f)),
                    modifier = Modifier.testTag("offline_ready_badge")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Pobrano offline",
                            tint = AccentEmerald,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Offline",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentEmerald
                        )
                    }
                }
            }
        }

        // Puma Companion / Rescue Mission Card (Always accessible to check puma status)
        Spacer(modifier = Modifier.height(14.dp))
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable { onOpenPumaMission() }
                .testTag("puma_companion_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = BorderStroke(
                1.5.dp,
                if (isPumaUnlocked) AccentAmber.copy(alpha = 0.7f) else Color(0xFFF59E0B).copy(alpha = 0.5f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(if (isPumaUnlocked) AccentAmber.copy(alpha = 0.2f) else Color(0xFFF59E0B).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(
                            id = if (isPumaUnlocked) R.drawable.img_cute_puma else R.drawable.img_sad_puma_cage
                        ),
                        contentDescription = if (isPumaUnlocked) "Słodziaśna Puma (Uwolniona!)" else "Smutna Puma w klatce",
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isPumaUnlocked) "🐾 Towarzysz: Słodziaśna Puma (Uwolniona!)" else "🐾 Misja: Uwolnij Pumę!",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPumaUnlocked) AccentAmber else Color(0xFFFBBF24)
                    )
                    Text(
                        text = if (isPumaUnlocked)
                            "Ukończyłeś wszystkie 43 lekcje – Puma jest szczęśliwa!"
                        else
                            "Ukończ wszystkie lekcje i uwolnij Pumę! ($completedCount / $totalLessons)",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Szczegóły",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Course completion progress bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Twój postęp w kursie",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "$completedCount z $totalLessons ukończonych (${(progressFraction * 100).toInt()}%)",
                        fontSize = 13.sp,
                        color = if (progressFraction >= 1f) AccentEmerald else AccentCyan,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (progressFraction >= 1f) AccentEmerald else AccentCyan,
                    trackColor = DarkSurfaceHighlight
                )

                if (isCourseDownloaded) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.OfflinePin,
                            contentDescription = null,
                            tint = AccentEmerald,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "43 lekcje zapisane offline (~340 MB) • Brak zużycia danych",
                            fontSize = 11.sp,
                            color = AccentEmerald,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Quality of Life Action Chip: Odznaki
        Surface(
            onClick = onOpenAchievements,
            shape = RoundedCornerShape(12.dp),
            color = AccentAmber.copy(alpha = 0.12f),
            border = BorderStroke(1.dp, AccentAmber.copy(alpha = 0.35f)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("header_achievements_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = "Odznaki",
                    tint = AccentAmber,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Centrum Osiągnięć i Odznak ($unlockedAchievementsCount / $totalAchievementsCount)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentAmber
                    )
                    Text(
                        text = if (isPumaUnlocked) "🐾 Złota Puma zdobyta – gratulacje!" else "🐾 Główny cel: Uwolnij Pumę ($completedCount / 43 lekcji)",
                        fontSize = 10.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = AccentAmber.copy(alpha = 0.8f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun ResumeLessonCard(
    lesson: LessonItem,
    progress: LessonProgressEntity?,
    isCurrentPlaying: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .clickable(onClick = onClick)
            .testTag("resume_card"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(AccentCyan),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = DarkSurface,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "KONTYNUUJ NAUKĘ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    letterSpacing = 1.sp
                )
                Text(
                    text = lesson.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val durationText = formatSeconds(lesson.durationSec)
                val progressText = if (progress != null && progress.lastPositionMs > 0) {
                    val posSec = (progress.lastPositionMs / 1000).toInt()
                    "Wstrzymano w ${formatSeconds(posSec)} • Długość $durationText"
                } else {
                    "Długość: $durationText"
                }
                Text(
                    text = progressText,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }

            if (isCurrentPlaying) {
                AudioWaveformView(isPlaying = true, barCount = 6, maxHeight = 28.dp)
            }
        }
    }
}

@Composable
private fun ModuleAccordionCard(
    module: CourseModule,
    isExpanded: Boolean,
    completedCount: Int,
    progressMap: Map<String, LessonProgressEntity>,
    currentPlayingLessonId: String?,
    isPlaying: Boolean,
    onToggleExpand: () -> Unit,
    onLessonClick: (LessonItem) -> Unit,
    onDownloadLesson: (LessonItem) -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .testTag("module_${module.id}_card"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column {
            // Module Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggleExpand)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = module.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    if (module.description.isNotEmpty()) {
                        Text(
                            text = module.description,
                            fontSize = 12.sp,
                            color = TextSecondary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "${module.lessons.size} lekcji • $completedCount/${module.lessons.size} ukończono",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (completedCount == module.lessons.size && completedCount > 0) AccentEmerald else AccentCyan
                    )
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Zwiń" else "Rozwiń",
                    tint = TextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Lessons List (Expandable)
            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceVariant)
                        .padding(bottom = 6.dp)
                ) {
                    module.lessons.forEach { lesson ->
                        val progress = progressMap[lesson.id]
                        val isCurrent = lesson.id == currentPlayingLessonId
                        LessonItemRow(
                            lesson = lesson,
                            progress = progress,
                            isCurrent = isCurrent,
                            isPlaying = isCurrent && isPlaying,
                            onClick = { onLessonClick(lesson) },
                            onDownloadClick = { onDownloadLesson(lesson) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonItemRow(
    lesson: LessonItem,
    progress: LessonProgressEntity?,
    isCurrent: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onDownloadClick: () -> Unit = {}
) {
    val isCompleted = progress?.isCompleted == true
    val isDownloaded = progress?.isDownloaded == true
    val durationText = formatSeconds(lesson.durationSec)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (isCurrent) DarkSurfaceHighlight else Color.Transparent)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("lesson_${lesson.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icon / Status indicator
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isCurrent -> AccentCyan
                        isCompleted -> AccentEmerald.copy(alpha = 0.2f)
                        else -> DarkSurface
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isCurrent && isPlaying) {
                AudioWaveformView(isPlaying = true, barCount = 4, maxHeight = 16.dp)
            } else if (isCompleted) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Ukończono",
                    tint = AccentEmerald,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Odtwórz",
                    tint = if (isCurrent) DarkSurface else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Lesson Title & Meta
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = lesson.title,
                fontSize = 14.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                color = if (isCurrent) AccentCyan else TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text(
                    text = durationText,
                    fontSize = 12.sp,
                    color = TextMuted
                )

                if (isDownloaded) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.OfflinePin,
                        contentDescription = "Pobrano offline",
                        tint = AccentCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "Offline",
                        fontSize = 11.sp,
                        color = AccentCyan
                    )
                }

                if (isCompleted) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• Ukończona",
                        fontSize = 11.sp,
                        color = AccentEmerald
                    )
                } else if (progress != null && progress.lastPositionMs > 5000L) {
                    Spacer(modifier = Modifier.width(8.dp))
                    val pct = (progress.lastPositionMs.toFloat() / (lesson.durationSec * 1000L).toFloat() * 100).toInt()
                    Text(
                        text = "• W trakcie ($pct%)",
                        fontSize = 11.sp,
                        color = AccentAmber
                    )
                }
            }
        }

        if (!isDownloaded) {
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onDownloadClick,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
                    .testTag("download_lesson_btn_${lesson.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.CloudDownload,
                    contentDescription = "Pobierz tę lekcję",
                    tint = AccentCyan,
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}

private fun formatSeconds(seconds: Int): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format("%d:%02d", mins, secs)
}
