package com.example.ui.components

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.R
import com.example.model.Achievement
import com.example.model.AchievementIcon
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// Confetti Particle model
private data class ConfettiParticle(
    val initialXRatio: Float,
    val initialYRatio: Float,
    val speedX: Float,
    val speedY: Float,
    val flutterFrequency: Float,
    val size: Float,
    val color: Color,
    val rotationSpeed: Float,
    val shapeType: Int // 0 = rect, 1 = circle, 2 = star
)

@Composable
fun ConfettiCanvas(
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val progress = remember { Animatable(0f) }

    val particles = remember {
        val colors = listOf(
            Color(0xFFF59E0B), // Gold
            Color(0xFF10B981), // Emerald
            Color(0xFF06B6D4), // Cyan
            Color(0xFFEC4899), // Pink
            Color(0xFF8B5CF6), // Violet
            Color(0xFFFBBF24), // Amber
            Color(0xFF38BDF8), // Sky
            Color(0xFF14B8A6)  // Teal
        )
        List(65) {
            ConfettiParticle(
                initialXRatio = 0.5f + (Random.nextFloat() - 0.5f) * 0.4f,
                initialYRatio = 0.2f + Random.nextFloat() * 0.15f,
                speedX = (Random.nextFloat() - 0.5f) * 600f,
                speedY = -150f + Random.nextFloat() * 450f,
                flutterFrequency = 4f + Random.nextFloat() * 8f,
                size = 10f + Random.nextFloat() * 16f,
                color = colors[it % colors.size],
                rotationSpeed = (Random.nextFloat() - 0.5f) * 720f,
                shapeType = Random.nextInt(3)
            )
        }
    }

    LaunchedEffect(isActive) {
        if (isActive) {
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 3500, easing = LinearEasing)
            )
        }
    }

    if (isActive && progress.value < 1f) {
        val t = progress.value
        val alpha = if (t > 0.75f) (1f - (t - 0.75f) / 0.25f).coerceIn(0f, 1f) else 1f

        Canvas(modifier = modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height
            val starPath = Path()

            particles.forEach { p ->
                // Physics: x moves with speed and sinusoidal wobble
                val wobble = sin(t * p.flutterFrequency * Math.PI.toFloat()) * 30f
                val x = (p.initialXRatio * canvasW) + (p.speedX * t) + wobble
                // y moves with initial upward velocity and gravity acceleration (g * t^2)
                val gravity = 900f * t * t
                val y = (p.initialYRatio * canvasH) + (p.speedY * t) + gravity

                if (x in -50f..(canvasW + 50f) && y in -50f..(canvasH + 50f)) {
                    val rotation = t * p.rotationSpeed
                    val drawColor = p.color.copy(alpha = alpha)

                    rotate(degrees = rotation, pivot = Offset(x, y)) {
                        when (p.shapeType) {
                            0 -> {
                                // Rectangle ribbon
                                drawRect(
                                    color = drawColor,
                                    topLeft = Offset(x - p.size / 2, y - p.size / 4),
                                    size = Size(p.size, p.size / 2)
                                )
                            }
                            1 -> {
                                // Sparkling circle
                                drawCircle(
                                    color = drawColor,
                                    radius = p.size / 3f,
                                    center = Offset(x, y)
                                )
                            }
                            else -> {
                                // 4-pointed Star
                                starPath.reset()
                                val r = p.size / 2f
                                val innerR = r * 0.4f
                                for (i in 0 until 8) {
                                    val angle = (i * Math.PI / 4).toFloat()
                                    val dist = if (i % 2 == 0) r else innerR
                                    val px = x + cos(angle) * dist
                                    val py = y + sin(angle) * dist
                                    if (i == 0) starPath.moveTo(px, py) else starPath.lineTo(px, py)
                                }
                                starPath.close()
                                drawPath(starPath, color = drawColor)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CelebrationBadgeOverlay(
    achievement: Achievement,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var visible by remember { mutableStateOf(false) }

    // Haptic feedback burst on achievement unlock
    LaunchedEffect(achievement.id) {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val timings = longArrayOf(0, 80, 60, 100)
                    val amplitudes = intArrayOf(0, 180, 0, 255)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(180)
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        visible = true
        // Anonymous/subtle auto-dismiss after 4.5 seconds
        delay(4500)
        visible = false
        delay(350)
        onDismiss()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .zIndex(999f)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                visible = false
                onDismiss()
            },
        contentAlignment = Alignment.TopCenter
    ) {
        // Confetti falling all over screen
        ConfettiCanvas(
            isActive = visible,
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically(
                initialOffsetY = { -it },
                animationSpec = tween(400)
            ) + fadeIn(tween(300)),
            exit = slideOutVertically(
                targetOffsetY = { -it },
                animationSpec = tween(300)
            ) + fadeOut(tween(250)),
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 40.dp)
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            val isPuma = achievement.iconType == AchievementIcon.PUMA_MASTER

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(16.dp, shape = RoundedCornerShape(24.dp))
                    .testTag("celebration_badge_popup"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(
                    2.dp,
                    if (isPuma) AccentAmber.copy(alpha = 0.9f) else AccentEmerald.copy(alpha = 0.7f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Bar with subtle tag and close
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isPuma) AccentAmber.copy(alpha = 0.2f) else AccentEmerald.copy(alpha = 0.18f),
                            border = BorderStroke(
                                1.dp,
                                if (isPuma) AccentAmber.copy(alpha = 0.5f) else AccentEmerald.copy(alpha = 0.4f)
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = if (isPuma) AccentAmber else AccentEmerald,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isPuma) "LEGENDA KURSU" else "NOWA ODZNAKA!",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isPuma) AccentAmber else AccentEmerald,
                                    letterSpacing = 1.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                visible = false
                                onDismiss()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Zamknij",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (isPuma) {
                        // SŁODZIAŚNA PUMA HERO VISUAL!
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(AccentAmber.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_cute_puma),
                                contentDescription = "Słodziaśna Puma",
                                modifier = Modifier
                                    .size(102.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "🐾 PUMA JEST WOLNA I SZCZĘŚLIWA! 🐾",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = AccentAmber,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        // Chapter / Achievement Icon
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(AccentEmerald.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = getCelebrationIcon(achievement.iconType),
                                contentDescription = null,
                                tint = AccentEmerald,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = achievement.title,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = achievement.description,
                        fontSize = 13.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Dotknij, aby kontynuować • Ciesz się nauką!",
                        fontSize = 11.sp,
                        color = AccentCyan,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

private fun getCelebrationIcon(iconType: AchievementIcon): ImageVector {
    return when (iconType) {
        AchievementIcon.FIRST_LESSON -> Icons.Default.School
        AchievementIcon.STREAK_3 -> Icons.Default.Whatshot
        AchievementIcon.STREAK_7 -> Icons.Default.EmojiEvents
        AchievementIcon.STREAK_14 -> Icons.Default.EmojiEvents
        AchievementIcon.TOTAL_1H -> Icons.Default.EmojiEvents
        AchievementIcon.TOTAL_5H -> Icons.Default.EmojiEvents
        AchievementIcon.TOTAL_10H -> Icons.Default.EmojiEvents
        AchievementIcon.RUNNER_WARRIOR -> Icons.Default.EmojiEvents
        AchievementIcon.EARLY_BIRD -> Icons.Default.EmojiEvents
        AchievementIcon.NIGHT_OWL -> Icons.Default.EmojiEvents
        AchievementIcon.MODULE_MASTER -> Icons.Default.School
        AchievementIcon.BRAVE_HEART -> Icons.Default.Favorite
        AchievementIcon.MODULE_0_DONE -> Icons.Default.CheckCircle
        AchievementIcon.MODULE_1_DONE -> Icons.Default.RecordVoiceOver
        AchievementIcon.MODULE_2_DONE -> Icons.Default.ShoppingCart
        AchievementIcon.MODULE_3_DONE -> Icons.Default.LocationCity
        AchievementIcon.MODULE_4_DONE -> Icons.Default.Hearing
        AchievementIcon.MODULE_AIRPORT_DONE -> Icons.Default.Flight
        AchievementIcon.PUMA_MASTER -> Icons.Default.Pets
    }
}
