package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DayActivity
import com.example.model.HabitStats
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DailyHabitCard(
    habitStats: HabitStats,
    weeklyActivity: List<DayActivity> = emptyList(),
    unlockedAchievementsCount: Int = 0,
    totalAchievementsCount: Int = 11,
    reminderTimeText: String? = null,
    onSetDailyGoal: (Int) -> Unit,
    onOpenAchievements: () -> Unit = {},
    onOpenReminder: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val todayMinutes = habitStats.todayMinutes
    val goalMinutes = habitStats.dailyGoalMinutes
    val progress = habitStats.goalProgressFraction
    val isGoalAchieved = habitStats.isGoalReached
    val streakDays = habitStats.streakDays

    val goalOptions = listOf(10, 15, 20, 30)
    var selectedDayDetail by remember { mutableStateOf<DayActivity?>(null) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .testTag("daily_habit_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(
            1.dp,
            if (isGoalAchieved) AccentEmerald.copy(alpha = 0.5f) else DarkSurfaceHighlight
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .animateContentSize()
        ) {
            // Header Row: Flame / Streak Badge + Daily Habit Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (streakDays > 0) AccentAmber.copy(alpha = 0.2f) else DarkSurfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Whatshot,
                            contentDescription = "Seria dni",
                            tint = if (streakDays > 0) AccentAmber else TextMuted,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Codzienny nawyk",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (streakDays > 1) "$streakDays dni nauki z rzędu 🔥" else if (todayMinutes > 0) "1 dzień z rzędu 🔥" else "Utrzymaj codzienną ciągłość",
                            fontSize = 12.sp,
                            color = if (streakDays > 1) AccentAmber else TextSecondary
                        )
                    }
                }

                // Total listening stat pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceVariant
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = habitStats.formattedTotalTime,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress Bar Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Dzisiaj: $todayMinutes / $goalMinutes min",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isGoalAchieved) AccentEmerald else TextPrimary
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isGoalAchieved) AccentEmerald else AccentCyan
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (isGoalAchieved) AccentEmerald else AccentCyan,
                trackColor = DarkSurfaceHighlight
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Motivational subtitle
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isGoalAchieved) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = AccentEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Dzisiejszy cel osiągnięty! Twój mózg utrwala angielski.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = AccentEmerald
                    )
                } else {
                    val remainingMins = (goalMinutes - todayMinutes).coerceAtLeast(1)
                    Text(
                        text = "Jeszcze $remainingMins min aktywnego słuchania do celu dnia.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }

            // WEEKLY CALENDAR STRIP (Feature 2)
            if (weeklyActivity.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Aktywność w tym tygodniu",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("weekly_activity_grid"),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    weeklyActivity.forEach { day ->
                        val isSelected = selectedDayDetail?.dateString == day.dateString
                        DayCalendarPill(
                            day = day,
                            isSelected = isSelected,
                            onClick = {
                                selectedDayDetail = if (isSelected) null else day
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Selected day detail toast
                AnimatedVisibility(visible = selectedDayDetail != null) {
                    selectedDayDetail?.let { day ->
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = DarkSurfaceVariant
                        ) {
                            Text(
                                text = when {
                                    day.isFuture -> "${day.dayOfWeekShort} (${day.dayOfMonth}): zaplanuj naukę w tym dniu!"
                                    day.isGoalReached -> "${day.dayOfWeekShort} (${day.dayOfMonth}): ${day.listenedMinutes} min (Cel ${day.goalMinutes}m zrealizowany! 🎉)"
                                    day.hasActivity -> "${day.dayOfWeekShort} (${day.dayOfMonth}): ${day.listenedMinutes} min słuchania"
                                    else -> "${day.dayOfWeekShort} (${day.dayOfMonth}): brak sesji słuchania"
                                },
                                fontSize = 11.sp,
                                color = if (day.isGoalReached) AccentEmerald else TextSecondary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Daily goal chips selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Cel dnia:",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(end = 8.dp)
                )

                goalOptions.forEach { minutes ->
                    val isSelected = goalMinutes == minutes
                    Surface(
                        onClick = { onSetDailyGoal(minutes) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) AccentCyan else DarkSurfaceVariant,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .testTag("goal_chip_${minutes}m")
                    ) {
                        Text(
                            text = "${minutes}m",
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) DarkSurface else TextPrimary,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Gamification Actions Row: Badges & Reminders
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Badges Button
                Surface(
                    onClick = onOpenAchievements,
                    shape = RoundedCornerShape(14.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(1.dp, AccentAmber.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("open_achievements_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(AccentAmber.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = AccentAmber,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "Odznaki",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "$unlockedAchievementsCount/$totalAchievementsCount zdobyte",
                                fontSize = 10.sp,
                                color = AccentAmber
                            )
                        }
                    }
                }

                // Reminder Button
                Surface(
                    onClick = onOpenReminder,
                    shape = RoundedCornerShape(14.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(1.dp, AccentCyan.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("open_reminder_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(AccentCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Alarm,
                                contentDescription = null,
                                tint = AccentCyan,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "Przypomnienie",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = reminderTimeText ?: "Wyłączone",
                                fontSize = 10.sp,
                                color = if (reminderTimeText != null) AccentCyan else TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCalendarPill(
    day: DayActivity,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isToday = day.isToday
    val isGoalReached = day.isGoalReached
    val hasActivity = day.hasActivity
    val isFuture = day.isFuture

    val bgColor = when {
        isSelected -> AccentCyan.copy(alpha = 0.2f)
        isToday -> DarkSurfaceHighlight
        else -> DarkSurfaceVariant.copy(alpha = 0.6f)
    }

    val borderColor = when {
        isToday -> AccentCyan
        isSelected -> AccentCyan.copy(alpha = 0.6f)
        isGoalReached -> AccentEmerald.copy(alpha = 0.4f)
        else -> Color.Transparent
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
            .padding(horizontal = 2.dp)
            .testTag("day_pill_${day.dateString}")
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = day.dayOfWeekShort,
                fontSize = 10.sp,
                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                color = if (isToday) AccentCyan else if (isFuture) TextMuted else TextSecondary
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "${day.dayOfMonth}",
                fontSize = 12.sp,
                fontWeight = if (isToday) FontWeight.Black else FontWeight.SemiBold,
                color = if (isToday) AccentCyan else if (isFuture) TextMuted else TextPrimary
            )

            Spacer(modifier = Modifier.height(3.dp))

            // Indicator Icon / Dot
            Box(
                modifier = Modifier.size(14.dp),
                contentAlignment = Alignment.Center
            ) {
                when {
                    isGoalReached -> {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = AccentEmerald,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                    hasActivity -> {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(AccentCyan)
                        )
                    }
                    isToday -> {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(AccentCyan.copy(alpha = 0.5f))
                        )
                    }
                    else -> {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceHighlight)
                        )
                    }
                }
            }
        }
    }
}
