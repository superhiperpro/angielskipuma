package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PumaRescueDialog(
    isUnlocked: Boolean,
    completedCount: Int,
    totalLessons: Int,
    onDismiss: () -> Unit,
    onStartLearning: () -> Unit = onDismiss,
    modifier: Modifier = Modifier
) {
    val remaining = (totalLessons - completedCount).coerceAtLeast(0)
    val progressFraction = (completedCount.toFloat() / totalLessons.toFloat().coerceAtLeast(1f)).coerceIn(0f, 1f)

    // Gentle heartbeat / floating animation for the puma badge
    val infiniteTransition = rememberInfiniteTransition(label = "puma_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (!isUnlocked) 1.03f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "puma_scale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.78f))
                .padding(horizontal = 20.dp, vertical = 24.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .clip(RoundedCornerShape(28.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {} // prevent dismissing when tapping inside
                    .shadow(24.dp, shape = RoundedCornerShape(28.dp))
                    .testTag("puma_rescue_dialog_card"),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(
                    2.dp,
                    if (isUnlocked) AccentAmber.copy(alpha = 0.8f) else Color(0xFFF59E0B).copy(alpha = 0.6f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Bar with Tag and Close Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isUnlocked) AccentAmber.copy(alpha = 0.2f) else Color(0xFFEF4444).copy(alpha = 0.18f),
                            border = BorderStroke(
                                1.dp,
                                if (isUnlocked) AccentAmber.copy(alpha = 0.5f) else Color(0xFFEF4444).copy(alpha = 0.4f)
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = if (isUnlocked) Icons.Default.AutoAwesome else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isUnlocked) AccentAmber else Color(0xFFF87171),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isUnlocked) "LEGENDA KURSU" else "MISJA SPECJALNA",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isUnlocked) AccentAmber else Color(0xFFF87171),
                                    letterSpacing = 1.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("puma_rescue_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Zamknij",
                                tint = TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Big Visual Illustration (Sad Puma in Cage vs Happy Freed Puma)
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = if (isUnlocked) listOf(
                                        AccentAmber.copy(alpha = 0.35f),
                                        Color.Transparent
                                    ) else listOf(
                                        Color(0xFFF59E0B).copy(alpha = 0.25f),
                                        DarkSurfaceVariant
                                    )
                                )
                            )
                            .testTag("puma_rescue_image_box"),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(
                                id = if (isUnlocked) R.drawable.img_cute_puma else R.drawable.img_sad_puma_cage
                            ),
                            contentDescription = if (isUnlocked) "Szczęśliwa wolna Puma" else "Smutna Puma w klatce",
                            modifier = Modifier
                                .size(144.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Bold Headline as requested by the user
                    Text(
                        text = if (isUnlocked) "Puma jest wolna i szczęśliwa!" else "Ukończ wszystkie lekcje i uwolnij Pumę!",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isUnlocked) AccentAmber else TextPrimary,
                        textAlign = TextAlign.Center,
                        lineHeight = 26.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Emotionally engaging story text
                    Text(
                        text = if (isUnlocked) {
                            "Niesamowite! Ukończyłeś wszystkie $totalLessons lekcji kursu Aktywny Angielski! Otworzyłeś klatkę i Puma biega teraz szczęśliwa na wolności jako Twój wierny towarzysz nauki! 🐾"
                        } else {
                            "Biedna mała Puma utknęła w klatce i z tęsknotą czeka na Twoją pomoc! Z każdą ukończoną lekcją angielskiego klatka słabnie. Ukończ cały kurs, a Puma odzyska wolność i będzie uśmiechnięta!"
                        },
                        fontSize = 13.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 19.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Progress Status Box
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = DarkSurfaceVariant.copy(alpha = 0.7f),
                        border = BorderStroke(1.dp, DarkSurfaceHighlight)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isUnlocked) "🐾 Status: Uwolniona!" else "🐾 Postęp ratowania:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUnlocked) AccentAmber else TextPrimary
                                )
                                Text(
                                    text = "$completedCount / $totalLessons lekcji",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isUnlocked) AccentAmber else AccentCyan
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LinearProgressIndicator(
                                progress = { progressFraction },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(CircleShape),
                                color = if (isUnlocked) AccentAmber else AccentEmerald,
                                trackColor = DarkBackground,
                                strokeCap = StrokeCap.Round
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (isUnlocked) {
                                    "✨ 100% zrealizowane • Mistrz Aktywnego Angielskiego!"
                                } else {
                                    "Jeszcze tylko $remaining ${if (remaining == 1) "lekcja" else "lekcji"} do otwarcia klatki!"
                                },
                                fontSize = 11.sp,
                                color = if (isUnlocked) AccentAmber else AccentCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Primary Action Button
                    Button(
                        onClick = {
                            onStartLearning()
                            onDismiss()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("puma_rescue_action_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isUnlocked) AccentAmber else AccentEmerald
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (isUnlocked) Icons.Default.Favorite else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isUnlocked) "Ciesz się sukcesem!" else "Uratuję Cię! Ruszam do nauki",
                            color = Color.Black,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    if (!isUnlocked) {
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("puma_rescue_later_button")
                        ) {
                            Text(
                                text = "Później, teraz tylko przeglądam",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
