package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Achievement
import com.example.model.AchievementCategory
import com.example.model.AchievementIcon
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentIndigo
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AchievementsSheet(
    achievements: List<Achievement>,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedCategory by remember { mutableStateOf<AchievementCategory?>(null) }

    val unlockedCount = achievements.count { it.isUnlocked }
    val totalCount = achievements.size.coerceAtLeast(1)
    val unlockedFraction = (unlockedCount.toFloat() / totalCount.toFloat()).coerceIn(0f, 1f)

    val filteredAchievements = if (selectedCategory == null) {
        achievements
    } else {
        achievements.filter { it.category == selectedCategory }
    }

    val userLevelTitle = when {
        unlockedCount >= 9 -> "Mistrz Angielskiego (Poziom 4)"
        unlockedCount >= 6 -> "Zaawansowany Słuchacz (Poziom 3)"
        unlockedCount >= 3 -> "Aktywny Uczeń (Poziom 2)"
        unlockedCount >= 1 -> "Początkujący (Poziom 1)"
        else -> "Nowy Słuchacz (Poziom 0)"
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkBackground,
        dragHandle = null,
        modifier = modifier.testTag("achievements_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(top = 16.dp, bottom = 24.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(AccentAmber.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = AccentAmber,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Odznaki i Osiągnięcia",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "$unlockedCount z $totalCount odblokowanych odznak",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .testTag("close_achievements_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Zamknij",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Overall Progress & Level Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, DarkSurfaceHighlight)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = AccentAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = userLevelTitle,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentAmber
                            )
                        }

                        Text(
                            text = "${(unlockedFraction * 100).toInt()}% ukończone",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AccentCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { unlockedFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = AccentAmber,
                        trackColor = DarkSurfaceHighlight
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Zdobywaj kolejne odznaki za codzienną naukę, utrzymywanie serii i słuchanie kursu w ruchu!",
                        fontSize = 11.sp,
                        color = TextMuted,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Category Filter Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    CategoryFilterChip(
                        label = "Wszystkie (${achievements.size})",
                        isSelected = selectedCategory == null,
                        onClick = { selectedCategory = null }
                    )
                }
                item {
                    CategoryFilterChip(
                        label = "Seria dni 🔥",
                        isSelected = selectedCategory == AchievementCategory.STREAK,
                        onClick = { selectedCategory = AchievementCategory.STREAK }
                    )
                }
                item {
                    CategoryFilterChip(
                        label = "Czas słuchania ⏱️",
                        isSelected = selectedCategory == AchievementCategory.TIME,
                        onClick = { selectedCategory = AchievementCategory.TIME }
                    )
                }
                item {
                    CategoryFilterChip(
                        label = "Wyzwania ⚡",
                        isSelected = selectedCategory == AchievementCategory.CHALLENGE,
                        onClick = { selectedCategory = AchievementCategory.CHALLENGE }
                    )
                }
                item {
                    CategoryFilterChip(
                        label = "Kurs 🎓",
                        isSelected = selectedCategory == AchievementCategory.COURSE,
                        onClick = { selectedCategory = AchievementCategory.COURSE }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Achievements List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredAchievements, key = { it.id }) { achievement ->
                    AchievementItemCard(achievement = achievement)
                }
            }
        }
    }
}

@Composable
private fun CategoryFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) AccentCyan else DarkSurfaceVariant,
        border = BorderStroke(
            1.dp,
            if (isSelected) AccentCyan else DarkSurfaceHighlight
        )
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) DarkSurface else TextPrimary,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
        )
    }
}

@Composable
private fun AchievementItemCard(
    achievement: Achievement,
    modifier: Modifier = Modifier
) {
    val isUnlocked = achievement.isUnlocked
    val iconVector = getIconVector(achievement.iconType)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("achievement_card_${achievement.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnlocked) DarkSurface else DarkSurface.copy(alpha = 0.7f)
        ),
        border = BorderStroke(
            1.dp,
            if (isUnlocked) AccentEmerald.copy(alpha = 0.45f) else DarkSurfaceHighlight.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Badge Icon Circle
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(
                        if (isUnlocked) {
                            if (achievement.iconType == AchievementIcon.PUMA_MASTER) AccentAmber.copy(alpha = 0.25f)
                            else AccentEmerald.copy(alpha = 0.2f)
                        } else DarkSurfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (achievement.iconType == AchievementIcon.PUMA_MASTER) {
                    Image(
                        painter = painterResource(id = R.drawable.img_cute_puma),
                        contentDescription = "Słodziaśna Puma (Mistrz Kursu)",
                        modifier = Modifier
                            .size(if (isUnlocked) 46.dp else 42.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop,
                        alpha = if (isUnlocked) 1f else 0.45f
                    )
                } else {
                    Icon(
                        imageVector = iconVector,
                        contentDescription = null,
                        tint = if (isUnlocked) AccentEmerald else TextMuted,
                        modifier = Modifier.size(26.dp)
                    )
                }

                if (!isUnlocked) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(DarkBackground.copy(alpha = 0.9f))
                            .align(Alignment.BottomEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Zablokowane",
                            tint = TextMuted,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Details Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = achievement.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isUnlocked) TextPrimary else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (isUnlocked) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = AccentEmerald,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "Zdobyte",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentEmerald
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = achievement.description,
                    fontSize = 12.sp,
                    color = TextMuted,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (isUnlocked) {
                    achievement.unlockedDate?.let { date ->
                        Text(
                            text = "Odblokowano: $date",
                            fontSize = 11.sp,
                            color = AccentEmerald.copy(alpha = 0.8f),
                            fontWeight = FontWeight.Medium
                        )
                    }
                } else {
                    // Progress Bar for locked items
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Postęp",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                            Text(
                                text = achievement.progressText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = AccentCyan
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        LinearProgressIndicator(
                            progress = { achievement.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = AccentCyan,
                            trackColor = DarkSurfaceHighlight
                        )
                    }
                }
            }
        }
    }
}

private fun getIconVector(iconType: AchievementIcon): ImageVector {
    return when (iconType) {
        AchievementIcon.FIRST_LESSON -> Icons.Default.School
        AchievementIcon.STREAK_3 -> Icons.Default.Whatshot
        AchievementIcon.STREAK_7 -> Icons.Default.LocalFireDepartment
        AchievementIcon.STREAK_14 -> Icons.Default.EmojiEvents
        AchievementIcon.TOTAL_1H -> Icons.Default.Timer
        AchievementIcon.TOTAL_5H -> Icons.Default.Timer
        AchievementIcon.TOTAL_10H -> Icons.Default.EmojiEvents
        AchievementIcon.RUNNER_WARRIOR -> Icons.Default.DirectionsRun
        AchievementIcon.EARLY_BIRD -> Icons.Default.WbSunny
        AchievementIcon.NIGHT_OWL -> Icons.Default.Nightlight
        AchievementIcon.MODULE_MASTER -> Icons.Default.School
        AchievementIcon.BRAVE_HEART -> Icons.Default.Favorite
        AchievementIcon.MODULE_0_DONE -> Icons.Default.CheckCircle
        AchievementIcon.MODULE_1_DONE -> Icons.Default.RecordVoiceOver
        AchievementIcon.MODULE_2_DONE -> Icons.Default.ShoppingCart
        AchievementIcon.MODULE_3_DONE -> Icons.Default.LocationCity
        AchievementIcon.MODULE_4_DONE -> Icons.Default.Hearing
        AchievementIcon.MODULE_AIRPORT_DONE -> Icons.Default.Flight
        AchievementIcon.PUMA_MASTER -> Icons.Default.Pets
    }
}
