package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF101726)
val DarkSurfaceVariant = Color(0xFF1B2438)
val DarkSurfaceHighlight = Color(0xFF26334D)

val AccentCyan = Color(0xFF38BDF8)
val AccentIndigo = Color(0xFF6366F1)
val AccentAmber = Color(0xFFF59E0B)
val AccentEmerald = Color(0xFF10B981)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val ProgressTrack = Color(0xFF1E293B)
val ProgressIndicator = Color(0xFF38BDF8)
