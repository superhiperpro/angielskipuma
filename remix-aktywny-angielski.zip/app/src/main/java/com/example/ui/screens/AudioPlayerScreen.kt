package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CourseManifest
import com.example.model.LessonItem
import com.example.model.PlaybackState
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.ui.components.AudioWaveformView
import com.example.ui.components.SleepTimerSheet
import com.example.ui.components.SpeedSelectorSheet
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentIndigo
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioPlayerScreen(
    manifest: CourseManifest,
    playbackState: PlaybackState,
    sleepTimerState: SleepTimerState,
    isCompleted: Boolean,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSeekBy: (Long) -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSpeedChange: (Float) -> Unit,
    onToggleCompleted: () -> Unit,
    onClosePlayer: () -> Unit,
    onStopAndClose: () -> Unit = {},
    onSetSleepTimer: (SleepTimerOption) -> Unit,
    onCancelSleepTimer: () -> Unit,
    onOpenRunnerMode: () -> Unit,
    onDismissError: () -> Unit = {},
    isVocalBoostEnabled: Boolean = true,
    onToggleVocalBoost: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val lesson = playbackState.currentLesson
    val module = manifest.modules.find { it.id == lesson?.moduleId }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }

    var isUserDraggingSlider by remember { mutableStateOf(false) }
    var sliderDragPosition by remember { mutableFloatStateOf(0f) }

    val currentMs = if (isUserDraggingSlider) sliderDragPosition.toLong() else playbackState.currentPositionMs
    val totalMs = playbackState.totalDurationMs.coerceAtLeast(1L)

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Navigation Bar (Collapse Arrow & Module Name)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClosePlayer,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
                    .testTag("close_player_button")
            ) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = "Zwiń odtwarzacz",
                    tint = TextPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            ) {
                Text(
                    text = "AKTYWNY ANGIELSKI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentCyan,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = module?.title ?: "Kurs audio",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (sleepTimerState.isActive) {
                    Surface(
                        onClick = { showSleepTimerSheet = true },
                        shape = RoundedCornerShape(16.dp),
                        color = AccentCyan.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(end = 8.dp).testTag("top_bar_sleep_timer_badge")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = AccentCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = sleepTimerState.formattedRemaining,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentCyan
                            )
                        }
                    }
                }

                // Mark as completed toggle
                IconButton(
                    onClick = onToggleCompleted,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isCompleted) AccentEmerald.copy(alpha = 0.2f) else DarkSurfaceVariant)
                        .testTag("toggle_completed_button")
                ) {
                    Icon(
                        imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Outlined.CheckCircleOutline,
                        contentDescription = if (isCompleted) "Oznaczona jako ukończona" else "Oznacz jako ukończoną",
                        tint = if (isCompleted) AccentEmerald else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Stop playback and close service button
                IconButton(
                    onClick = onStopAndClose,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .testTag("stop_and_exit_top_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Zatrzymaj odtwarzacz i wyłącz w tle",
                        tint = TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Big Album Art with ambient glow
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .aspectRatio(1f)
                .shadow(elevation = 20.dp, shape = RoundedCornerShape(32.dp), spotColor = AccentCyan)
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(AccentIndigo, AccentCyan)
                    )
                )
                .padding(3.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.course_cover_art),
                contentDescription = "Okładka kursu",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(29.dp))
            )

            // Animated acoustic waveform overlay at bottom of cover
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, DarkBackground.copy(alpha = 0.85f))
                        )
                    )
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                AudioWaveformView(
                    isPlaying = playbackState.isPlaying,
                    barCount = 18,
                    maxHeight = 32.dp
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Lesson Title & Details
        Text(
            text = lesson?.title ?: "Wybierz lekcję",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (lesson != null) "Lekcja ${lesson.lessonNumber} • Czysty trening słuchowy" else "Gotowy do odtwarzania",
            fontSize = 14.sp,
            color = AccentCyan,
            textAlign = TextAlign.Center
        )

        if (playbackState.errorMessage != null) {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceHighlight),
                border = androidx.compose.foundation.BorderStroke(1.dp, AccentAmber.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = AccentAmber,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Uwaga",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = playbackState.errorMessage,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                    IconButton(
                        onClick = onDismissError,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Zamknij powiadomienie",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Time Slider & Scrubbing Bar
        Column(modifier = Modifier.fillMaxWidth()) {
            Slider(
                value = currentMs.toFloat().coerceIn(0f, totalMs.toFloat()),
                onValueChange = { newPos ->
                    isUserDraggingSlider = true
                    sliderDragPosition = newPos
                },
                onValueChangeFinished = {
                    onSeekTo(sliderDragPosition.toLong())
                    isUserDraggingSlider = false
                },
                valueRange = 0f..totalMs.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = AccentCyan,
                    activeTrackColor = AccentCyan,
                    inactiveTrackColor = DarkSurfaceHighlight
                ),
                modifier = Modifier.testTag("audio_scrub_slider")
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMs(currentMs),
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Text(
                    text = "-${formatMs(totalMs - currentMs)}",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main Audio Playback Controls (Designed for walking/running/driving)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rewind 10 seconds
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onSeekBy(-10_000L) }
                    .padding(8.dp)
                    .testTag("rewind_10_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Replay10,
                    contentDescription = "Cofnij 10 sekund",
                    tint = TextPrimary,
                    modifier = Modifier.size(36.dp)
                )
                Text(
                    text = "-10s",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            }

            // Previous Lesson
            IconButton(
                onClick = onPrevious,
                modifier = Modifier
                    .size(52.dp)
                    .testTag("previous_lesson_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipPrevious,
                    contentDescription = "Poprzednia lekcja",
                    tint = TextPrimary,
                    modifier = Modifier.size(36.dp)
                )
            }

            // BIG PLAY / PAUSE BUTTON (76dp touch target)
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(AccentCyan, AccentIndigo)
                        )
                    )
                    .clickable(onClick = onTogglePlayPause)
                    .testTag("main_play_pause_button"),
                contentAlignment = Alignment.Center
            ) {
                if (playbackState.isBuffering) {
                    CircularProgressIndicator(
                        color = DarkSurface,
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(36.dp)
                    )
                } else {
                    Icon(
                        imageVector = if (playbackState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (playbackState.isPlaying) "Pauza" else "Odtwarzaj",
                        tint = DarkSurface,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            // Next Lesson
            IconButton(
                onClick = onNext,
                modifier = Modifier
                    .size(52.dp)
                    .testTag("next_lesson_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Następna lekcja",
                    tint = TextPrimary,
                    modifier = Modifier.size(36.dp)
                )
            }

            // Forward 10 seconds
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onSeekBy(10_000L) }
                    .padding(8.dp)
                    .testTag("forward_10_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Forward10,
                    contentDescription = "Przewiń 10 sekund",
                    tint = TextPrimary,
                    modifier = Modifier.size(36.dp)
                )
                Text(
                    text = "+10s",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Bottom Controls: Speed, Sleep Timer, Runner Mode
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Speed Chip Button
            Surface(
                onClick = { showSpeedSheet = true },
                shape = RoundedCornerShape(20.dp),
                color = DarkSurfaceVariant,
                modifier = Modifier.testTag("speed_chip_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = AccentCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${playbackState.playbackSpeed}x",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }

            // Vocal Boost Chip Button
            Surface(
                onClick = onToggleVocalBoost,
                shape = RoundedCornerShape(20.dp),
                color = if (isVocalBoostEnabled) AccentCyan.copy(alpha = 0.2f) else DarkSurfaceVariant,
                border = if (isVocalBoostEnabled) androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f)) else null,
                modifier = Modifier.testTag("vocal_boost_chip_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = if (isVocalBoostEnabled) AccentCyan else TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isVocalBoostEnabled) "Głos +6dB" else "Głos 0dB",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isVocalBoostEnabled) AccentCyan else TextPrimary
                    )
                }
            }

            // Sleep Timer Chip Button
            Surface(
                onClick = { showSleepTimerSheet = true },
                shape = RoundedCornerShape(20.dp),
                color = if (sleepTimerState.isActive) AccentCyan.copy(alpha = 0.2f) else DarkSurfaceVariant,
                border = if (sleepTimerState.isActive) androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f)) else null,
                modifier = Modifier.testTag("bottom_sleep_timer_chip")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = if (sleepTimerState.isActive) AccentCyan else TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (sleepTimerState.isActive) sleepTimerState.formattedRemaining else "Timer",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (sleepTimerState.isActive) AccentCyan else TextPrimary
                    )
                }
            }

            // Runner / Distraction-free Mode Chip Button
            Surface(
                onClick = onOpenRunnerMode,
                shape = RoundedCornerShape(20.dp),
                color = DarkSurfaceVariant,
                modifier = Modifier.testTag("runner_mode_chip_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsRun,
                        contentDescription = null,
                        tint = AccentCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "W ruchu",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big clear button to stop playback and terminate background service
        Surface(
            onClick = onStopAndClose,
            shape = RoundedCornerShape(16.dp),
            color = DarkSurfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, TextMuted.copy(alpha = 0.25f)),
            modifier = Modifier.testTag("stop_and_exit_bottom_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Zatrzymaj i wyłącz w tle",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    if (showSpeedSheet) {
        SpeedSelectorSheet(
            currentSpeed = playbackState.playbackSpeed,
            onSpeedSelected = onSpeedChange,
            onDismiss = { showSpeedSheet = false }
        )
    }

    if (showSleepTimerSheet) {
        SleepTimerSheet(
            sleepTimerState = sleepTimerState,
            onOptionSelected = onSetSleepTimer,
            onCancelTimer = onCancelSleepTimer,
            onDismiss = { showSleepTimerSheet = false }
        )
    }
}

private fun formatMs(ms: Long): String {
    val totalSecs = (ms / 1000).coerceAtLeast(0)
    val mins = totalSecs / 60
    val secs = totalSecs % 60
    return String.format("%d:%02d", mins, secs)
}
