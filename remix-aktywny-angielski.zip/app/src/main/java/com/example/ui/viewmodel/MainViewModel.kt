package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.LessonProgressEntity
import com.example.data.download.GoogleDriveDownloader
import com.example.data.repository.CourseRepository
import com.example.data.repository.LocalAudioImporter
import com.example.model.Achievement
import com.example.model.CourseManifest
import com.example.model.DailyReminderConfig
import com.example.model.DayActivity
import com.example.model.DownloadProgressState
import com.example.model.HabitStats
import com.example.model.LessonItem
import com.example.model.PlaybackState
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.playback.AudioPlaybackManager
import com.example.playback.AudioSampleGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    DOWNLOAD,
    COURSE_LIST,
    PLAYER,
    RUNNER_MODE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = CourseRepository(application)
    private val downloader = GoogleDriveDownloader(application, repository)
    val localAudioImporter = LocalAudioImporter(application, repository)

    val manifest: CourseManifest = repository.manifest

    val downloadState: StateFlow<DownloadProgressState> = downloader.downloadState
    val playbackState: StateFlow<PlaybackState> = AudioPlaybackManager.playbackState
    val isCourseDownloaded: StateFlow<Boolean> = repository.isCourseDownloadedFlow
    val sleepTimerState: StateFlow<SleepTimerState> = AudioPlaybackManager.sleepTimerState
    val habitStats: StateFlow<HabitStats> = repository.habitStatsFlow
    val weeklyActivity: StateFlow<List<DayActivity>> = repository.weeklyActivityFlow
    val achievements: StateFlow<List<Achievement>> = repository.achievementsFlow
    val dailyReminderConfig: StateFlow<DailyReminderConfig> = repository.dailyReminderConfigFlow
    val newAchievementUnlocked: SharedFlow<Achievement> = repository.newAchievementUnlockedFlow

    private val _isVocalBoostEnabled = MutableStateFlow(AudioPlaybackManager.isVocalBoostEnabled)
    val isVocalBoostEnabled: StateFlow<Boolean> = _isVocalBoostEnabled.asStateFlow()

    private val _importStatusMessage = MutableStateFlow<String?>(null)
    val importStatusMessage: StateFlow<String?> = _importStatusMessage.asStateFlow()

    val allProgress: StateFlow<Map<String, LessonProgressEntity>> = repository.getAllProgress()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Default screen is ALWAYS the main course list so the user is never trapped
    private val _currentScreen = MutableStateFlow(AppScreen.COURSE_LIST)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _expandedModuleIds = MutableStateFlow<Set<Int>>(setOf(0, 1))
    val expandedModuleIds: StateFlow<Set<Int>> = _expandedModuleIds.asStateFlow()

    init {
        AudioPlaybackManager.init(application, repository)

        // Check if files already present on storage
        viewModelScope.launch {
            repository.verifyLocalFiles()
        }
    }

    fun startDownload() {
        if (repository.isCourseDownloaded || repository.areAllLessonsDownloaded()) {
            // Already downloaded: strictly do not allow re-downloading
            _currentScreen.value = AppScreen.COURSE_LIST
            return
        }
        viewModelScope.launch {
            val success = downloader.downloadAllLessons()
            if (success) {
                repository.isCourseDownloaded = true
                _currentScreen.value = AppScreen.COURSE_LIST
            }
        }
    }

    fun downloadSingleLesson(lesson: LessonItem) {
        viewModelScope.launch {
            downloader.downloadSingleLesson(lesson)
            repository.verifyLocalFiles()
        }
    }

    fun importFromFolder(treeUri: Uri) {
        viewModelScope.launch {
            val result = localAudioImporter.importFromTreeUri(treeUri)
            _importStatusMessage.value = result.message
            repository.verifyLocalFiles()
        }
    }

    fun importFromFiles(uris: List<Uri>) {
        viewModelScope.launch {
            val result = localAudioImporter.importFromUris(uris)
            _importStatusMessage.value = result.message
            repository.verifyLocalFiles()
        }
    }

    fun generateAllSampleAudios() {
        viewModelScope.launch {
            val allLessons = manifest.modules.flatMap { it.lessons }
            AudioSampleGenerator.generateAllMissingSamples(getApplication(), allLessons) { _, _ -> }
            repository.verifyLocalFiles()
            _importStatusMessage.value = "Wygenerowano wersje demonstracyjne dla wszystkich lekcji."
        }
    }

    fun clearImportStatus() {
        _importStatusMessage.value = null
    }

    fun clearErrorMessage() {
        AudioPlaybackManager.clearErrorMessage()
    }

    fun cancelDownload() {
        downloader.cancel()
    }

    fun skipDownloadForNow() {
        _currentScreen.value = AppScreen.COURSE_LIST
    }

    fun toggleModuleExpanded(moduleId: Int) {
        val current = _expandedModuleIds.value
        _expandedModuleIds.value = if (current.contains(moduleId)) {
            current - moduleId
        } else {
            current + moduleId
        }
    }

    fun playLesson(lesson: LessonItem) {
        val currentProgress = allProgress.value[lesson.id]
        val isDone = currentProgress?.isCompleted == true
        val lastPos = currentProgress?.lastPositionMs ?: 0L
        val startPos = if (isDone || lastPos >= (lesson.durationSec * 1000L - 3000L)) 0L else lastPos
        AudioPlaybackManager.playLesson(lesson, startPos)
        _currentScreen.value = AppScreen.PLAYER
    }

    fun stopPlaybackAndDismiss() {
        AudioPlaybackManager.stopAndRelease(stopService = true, clearLesson = true)
    }

    fun togglePlayPause() {
        AudioPlaybackManager.togglePlayPause()
    }

    fun seekTo(positionMs: Long) {
        AudioPlaybackManager.seekTo(positionMs)
    }

    fun seekBy(deltaMs: Long) {
        AudioPlaybackManager.seekBy(deltaMs)
    }

    fun setSpeed(speed: Float) {
        AudioPlaybackManager.setSpeed(speed)
    }

    fun toggleVocalBoost() {
        val newState = !AudioPlaybackManager.isVocalBoostEnabled
        AudioPlaybackManager.setVocalBoost(newState)
        _isVocalBoostEnabled.value = newState
    }

    fun playNext() {
        AudioPlaybackManager.playNext()
    }

    fun playPrevious() {
        AudioPlaybackManager.playPrevious()
    }

    fun openPlayer() {
        _currentScreen.value = AppScreen.PLAYER
    }

    fun closePlayer() {
        _currentScreen.value = AppScreen.COURSE_LIST
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun toggleLessonCompletion(lessonId: String) {
        viewModelScope.launch {
            val current = allProgress.value[lessonId]?.isCompleted ?: false
            repository.markLessonCompleted(lessonId, !current)
        }
    }

    fun setSleepTimer(option: SleepTimerOption) {
        AudioPlaybackManager.setSleepTimer(option)
    }

    fun cancelSleepTimer() {
        AudioPlaybackManager.cancelSleepTimer()
    }

    fun setDailyGoal(minutes: Int) {
        repository.setDailyGoal(minutes)
    }

    fun updateDailyReminderConfig(config: DailyReminderConfig) {
        repository.updateDailyReminderConfig(config)
    }

    fun sendTestReminder() {
        repository.sendTestDailyReminder()
    }

    fun openRunnerMode() {
        AudioPlaybackManager.isRunnerModeActive = true
        _currentScreen.value = AppScreen.RUNNER_MODE
    }

    fun closeRunnerMode() {
        AudioPlaybackManager.isRunnerModeActive = false
        _currentScreen.value = AppScreen.PLAYER
    }
}
