package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CourseManifest
import com.example.model.PlaybackState
import com.example.model.SleepTimerState
import com.example.ui.components.AudioWaveformView
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentIndigo
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * RunnerModeScreen:
 * Specjalny, minimalistyczny tryb pełnoekranowy o wysokim kontraście, zaprojektowany
 * do nauki podczas biegania, spaceru lub jazdy samochodem (Hands-Free / Distraction-Free).
 *
 * Cechy:
 * - Gigantyczne przyciski o wysokim kontraście (łatwe trafienie w ruchu).
 * - Obsługa gestów: przesunięcie palcem w lewo (następna lekcja), w prawo (poprzednia lekcja),
 *   podwójne stuknięcie w dowolne miejsce (Play / Pause).
 * - Opcjonalna "Blokada kieszeniowa" (Pocket Lock) chroniąca przed przypadkowymi kliknięciami.
 * - Wyraźny wskaźnik timera uśpienia.
 */
@Composable
fun RunnerModeScreen(
    manifest: CourseManifest,
    playbackState: PlaybackState,
    sleepTimerState: SleepTimerState,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSeekBy: (Long) -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSpeedChange: (Float) -> Unit,
    onCloseRunnerMode: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lesson = playbackState.currentLesson
    val module = manifest.modules.find { it.id == lesson?.moduleId }

    var isPocketLocked by remember { mutableStateOf(false) }
    var dragDistance by remember { mutableFloatStateOf(0f) }
    var isUserDraggingSlider by remember { mutableStateOf(false) }
    var sliderDragPosition by remember { mutableFloatStateOf(0f) }

    val currentMs = playbackState.currentPositionMs
    val totalMs = playbackState.totalDurationMs.coerceAtLeast(1L)
    val displayMs = if (isUserDraggingSlider) sliderDragPosition.toLong() else currentMs
    val progress = (displayMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF07090E)) // Ultra deep AMOLED black
            .pointerInput(isPocketLocked) {
                if (!isPocketLocked) {
                    detectTapGestures(
                        onDoubleTap = { onTogglePlayPause() }
                    )
                }
            }
            .pointerInput(isPocketLocked) {
                if (!isPocketLocked) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (dragDistance < -120f) {
                                onNext()
                            } else if (dragDistance > 120f) {
                                onPrevious()
                            }
                            dragDistance = 0f
                        },
                        onHorizontalDrag = { _, dragAmount ->
                            dragDistance += dragAmount
                        }
                    )
                }
            }
            .padding(horizontal = 24.dp, vertical = 20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Exit button
                Surface(
                    onClick = onCloseRunnerMode,
                    shape = RoundedCornerShape(20.dp),
                    color = DarkSurfaceVariant,
                    modifier = Modifier.testTag("exit_runner_mode_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Wyjdź z trybu biegacza",
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Wróć",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }
                }

                // Mode pill & Sleep Timer info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (sleepTimerState.isActive) {
                        Surface(
                            onClick = onOpenSleepTimer,
                            shape = RoundedCornerShape(20.dp),
                            color = AccentCyan.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f)),
                            modifier = Modifier.padding(end = 8.dp).testTag("runner_sleep_timer_badge")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Sleep timer",
                                    tint = AccentCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = sleepTimerState.formattedRemaining,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentCyan
                                )
                            }
                        }
                    }

                    // Pocket lock toggle
                    IconButton(
                        onClick = { isPocketLocked = !isPocketLocked },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (isPocketLocked) AccentCyan.copy(alpha = 0.2f) else DarkSurfaceVariant)
                            .testTag("pocket_lock_button")
                    ) {
                        Icon(
                            imageVector = if (isPocketLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = if (isPocketLocked) "Odblokuj ekran" else "Zablokuj ekran (kieszeń)",
                            tint = if (isPocketLocked) AccentCyan else TextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Center Content: Large Title & Module
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Running Mode Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AccentCyan.copy(alpha = 0.12f),
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsRun,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "TRYB W RUCHU / W AUCIE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyan,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Text(
                    text = module?.title?.uppercase() ?: "AKTYWNY ANGIELSKI",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary,
                    letterSpacing = 1.1.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = lesson?.title ?: "Wybierz lekcję",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    lineHeight = 34.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Waveform animation
                AudioWaveformView(
                    isPlaying = playbackState.isPlaying,
                    barCount = 24,
                    maxHeight = 36.dp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Interactive seekable slider in Runner Mode
                Slider(
                    value = displayMs.toFloat().coerceIn(0f, totalMs.toFloat()),
                    onValueChange = { newPos ->
                        if (!isPocketLocked) {
                            isUserDraggingSlider = true
                            sliderDragPosition = newPos
                        }
                    },
                    onValueChangeFinished = {
                        if (!isPocketLocked) {
                            onSeekTo(sliderDragPosition.toLong())
                            isUserDraggingSlider = false
                        }
                    },
                    valueRange = 0f..totalMs.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = AccentCyan,
                        activeTrackColor = AccentCyan,
                        inactiveTrackColor = DarkSurfaceHighlight
                    ),
                    enabled = !isPocketLocked,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("runner_seek_slider")
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatMs(displayMs),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "-${formatMs((totalMs - displayMs).coerceAtLeast(0L))}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                }
            }

            // Giant Controls Center
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Main Row of Giant Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rewind 10s (Giant 72dp target)
                    Surface(
                        onClick = { onSeekBy(-10_000L) },
                        shape = CircleShape,
                        color = DarkSurfaceVariant,
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("runner_rewind_10")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Replay10,
                                contentDescription = "Cofnij 10s",
                                tint = TextPrimary,
                                modifier = Modifier.size(34.dp)
                            )
                            Text(
                                text = "-10s",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AccentCyan
                            )
                        }
                    }

                    // Previous Lesson
                    Surface(
                        onClick = onPrevious,
                        shape = CircleShape,
                        color = DarkSurfaceHighlight,
                        modifier = Modifier
                            .size(56.dp)
                            .testTag("runner_previous_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.SkipPrevious,
                                contentDescription = "Poprzednia lekcja",
                                tint = TextPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    // HERO PLAY / PAUSE (Giant 104dp)
                    Box(
                        modifier = Modifier
                            .size(104.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(AccentCyan, AccentIndigo)
                                )
                            )
                            .clickable(onClick = onTogglePlayPause)
                            .testTag("runner_main_play_pause"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (playbackState.isBuffering) {
                            CircularProgressIndicator(
                                color = DarkSurface,
                                strokeWidth = 4.dp,
                                modifier = Modifier.size(48.dp)
                            )
                        } else {
                            Icon(
                                imageVector = if (playbackState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (playbackState.isPlaying) "Pauza" else "Odtwarzaj",
                                tint = DarkSurface,
                                modifier = Modifier.size(56.dp)
                            )
                        }
                    }

                    // Next Lesson
                    Surface(
                        onClick = onNext,
                        shape = CircleShape,
                        color = DarkSurfaceHighlight,
                        modifier = Modifier
                            .size(56.dp)
                            .testTag("runner_next_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = "Następna lekcja",
                                tint = TextPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    // Forward 10s (Giant 72dp target)
                    Surface(
                        onClick = { onSeekBy(10_000L) },
                        shape = CircleShape,
                        color = DarkSurfaceVariant,
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("runner_forward_10")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Forward10,
                                contentDescription = "Przewiń 10s",
                                tint = TextPrimary,
                                modifier = Modifier.size(34.dp)
                            )
                            Text(
                                text = "+10s",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AccentCyan
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Speed buttons row (0.8x, 1.0x, 1.25x, 1.5x)
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(0.8f, 1.0f, 1.25f, 1.5f).forEach { speed ->
                        val isSelected = playbackState.playbackSpeed == speed
                        Surface(
                            onClick = { onSpeedChange(speed) },
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) AccentCyan else DarkSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        ) {
                            Text(
                                text = "${speed}x",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) DarkSurface else TextPrimary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Gesty: 👈 Przesuń (następna) • 👉 (poprzednia) • 👆👆 Podwójny stuk (Play/Pauza)",
                    fontSize = 11.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Pocket Lock Overlay (Protected against accidental screen taps)
        AnimatedVisibility(
            visible = isPocketLocked,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.88f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { /* swallow accidental taps */ }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Ekran zablokowany",
                        tint = AccentCyan,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Blokada kieszeniowa włączona",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Dotknięcia są zablokowane, aby nic nie przełączało się w kieszeni lub w biegu.",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Surface(
                        onClick = { isPocketLocked = false },
                        shape = RoundedCornerShape(20.dp),
                        color = AccentCyan,
                        modifier = Modifier.testTag("unlock_pocket_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = DarkSurface,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Odblokuj ekran",
                                color = DarkSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSecs = (ms / 1000).coerceAtLeast(0)
    val mins = totalSecs / 60
    val secs = totalSecs % 60
    return String.format("%d:%02d", mins, secs)
}
