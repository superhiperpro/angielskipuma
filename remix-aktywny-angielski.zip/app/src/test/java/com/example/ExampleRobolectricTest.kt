package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Aktywny Angielski", appName)
  }

  @Test
  fun `verify course manifest has 43 lessons and 6 modules`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.repository.CourseRepository(context)
    val manifest = repo.manifest
    assertEquals(43, manifest.totalLessons)
    assertEquals(6, manifest.modules.size)
    val totalInModules = manifest.modules.sumOf { it.lessons.size }
    assertEquals(43, totalInModules)
  }

  @Test
  fun `verify isCourseDownloaded reflects preferences and StateFlow`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.repository.CourseRepository(context)
    repo.isCourseDownloaded = true
    assertEquals(true, repo.isCourseDownloaded)
    assertEquals(true, repo.isCourseDownloadedFlow.value)
  }

  @Test
  fun `verify weekly activity returns 7 days`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.repository.CourseRepository(context)
    val weekly = repo.weeklyActivityFlow.value
    assertEquals(7, weekly.size)
  }

  @Test
  fun `verify achievements list has at least 11 badges`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.repository.CourseRepository(context)
    val achievements = repo.achievementsFlow.value
    assertEquals(true, achievements.size >= 11)
  }

  @Test
  fun `verify reminder config persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.repository.CourseRepository(context)
    val config = com.example.model.DailyReminderConfig(isEnabled = true, hour = 8, minute = 30)
    repo.updateDailyReminderConfig(config)
    val updated = repo.dailyReminderConfigFlow.value
    assertEquals(true, updated.isEnabled)
    assertEquals(8, updated.hour)
    assertEquals(30, updated.minute)
  }

  @Test
  fun `verify AudioSampleGenerator produces playable audio file in sample folder`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.repository.CourseRepository(context)
    val firstLesson = repo.manifest.modules.first().lessons.first()
    val audioFile = com.example.playback.AudioSampleGenerator.generateSampleAudio(context, firstLesson, durationSeconds = 3)
    assertEquals(true, audioFile.exists())
    assertEquals(true, audioFile.length() > 5000)
    // Check RIFF header
    val header = ByteArray(4)
    audioFile.inputStream().use { it.read(header) }
    assertEquals('R'.code.toByte(), header[0])
    assertEquals('I'.code.toByte(), header[1])
    assertEquals('F'.code.toByte(), header[2])
    assertEquals('F'.code.toByte(), header[3])
    // Verify repository rejects synthetic sample file as course audio
    val isGenuine = repo.isGenuineAudioFile(audioFile, 3_000_000L)
    assertEquals(false, isGenuine)
  }

  @Test
  fun `verify vocal boost state toggle`() {
    val manager = com.example.playback.AudioPlaybackManager
    manager.setVocalBoost(true)
    assertEquals(true, manager.isVocalBoostEnabled)
    manager.setVocalBoost(false)
    assertEquals(false, manager.isVocalBoostEnabled)
    manager.setVocalBoost(true)
    assertEquals(true, manager.isVocalBoostEnabled)
  }
}
